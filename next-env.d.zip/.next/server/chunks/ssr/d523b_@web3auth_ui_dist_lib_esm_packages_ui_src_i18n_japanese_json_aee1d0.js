module.exports = {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/japanese.json.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>japanese),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "{{adapter}} アカウントを確認して続行する",
    "adapter-loader.message1": "{{adapter}} を確認する",
    "adapter-loader.message2": "続行するアカウント",
    "errors-invalid-email": "無効な電子メール",
    "errors-invalid-number": "無効な電話番号",
    "errors-invalid-number-email": "無効なメールアドレスまたは電話番号",
    "errors-required": "必須",
    "external.back": "戻る",
    "external.connect": "ウォレットを続ける",
    "external.search-text": "財布が見えませんか？",
    "external.search-subtext": "代わりに検索してみてください",
    "external.connect-wallet": "ウォレットを接続",
    "external.continue": "外部ウォレットを続行する",
    "external.dont-have": "持っていない",
    "external.get": "取得",
    "external.get-wallet": "ウォレットを取得",
    "external.install-browser-extension": "{{browser}} 拡張機能をインストール",
    "external.install-mobile-app": "{{os}}アプリをインストール",
    "external.installed": "インストール済み",
    "external.no-wallets-found": "ウォレットが見つかりません",
    "external.search-wallet": "{{count}} ウォレットを検索...",
    "external.title": "外部ウォレット",
    "external.walletconnect-connect": "接続する",
    "external.walletconnect-copy": "WalletConnect がサポートするウォレットでスキャンするか、QR コードをクリックしてクリップボードにコピーします。",
    "external.walletconnect-subtitle": "WalletConnect対応ウォレットでQRコードをスキャンしてください",
    "footer.message": "自己保管ログイン by",
    "footer.message-new": "経由の自立",
    "footer.policy": "プライバシーポリシー",
    "footer.terms": "利用規約",
    "footer.terms-service": "利用規約",
    "footer.version": "バージョン",
    "header-subtitle": "続行するために以下のオプションのいずれかを選択してください",
    "header-subtitle-name": "ワンクリックで {{appName}} ウォレット",
    "header-subtitle-new": "ワンクリックであなたのブロックチェーンウォレット",
    "header-title": "ログイン",
    "header-tooltip-desc": "ウォレットは、ブロックチェーン上でデジタル資産を保存および管理するためのアカウントとして機能します。",
    "header-tooltip-title": "ウォレット",
    "network.add-request": "このサイトはネットワークの追加をリクエストしています",
    "network.cancel": "キャンセル",
    "network.from": "から",
    "network.proceed": "進む",
    "network.switch-request": "このサイトはネットワークの切り替えを要求しています",
    "network.to": "へ",
    "passkey.add": "{パス}を追加",
    "passkey.haveExisting": "既存の passkey をお持ちですか?",
    "passkey.learn-more": "もっと詳しく知る",
    "passkey.or": "または",
    "passkey.register-desc": "passkeys を使用すると、顔、指紋、またはセキュリティ キーを使用して本人確認を行うことができます。",
    "passkey.register-title": "Passkey を登録する",
    "passkey.use": "Passkey を持っています",
    "popup.phone-body": "国コードは自動的に検出されますが、異なる国の電話番号を使用する場合は、正しい国コードを手動で入力する必要があります。",
    "popup.phone-header": "電話番号と国コード",
    "post-loading.connected": "アカウントに接続されています",
    "post-loading.something-wrong": "何かがうまくいかなかった！",
    "social.continue": "続ける",
    "social.continueCustom": "{{adapter}}を続けます",
    "social.email": "Eメール",
    "social.email-continue": "メールで続行",
    "social.email-new": "name@example.com",
    "social.passwordless-cta": "続ける",
    "social.passwordless-login": "ログイン",
    "social.passwordless-title": "メールまたは電話",
    "social.phone": "電話",
    "social.policy": "ソーシャルログインに関連するデータは保存されません。",
    "social.sms": "モバイル",
    "social.sms-continue": "モバイルで続行",
    "social.sms-invalid-number": "無効な電話番号",
    "social.sms-placeholder-text": "例:",
    "social.view-less": "表示が少なくなります",
    "social.view-less-socials": "表示を減らす socials",
    "social.view-more": "もっと見る",
    "social.view-more-socials": "もっと見る socials"
};
var japanese = {
    modal: modal
};
;
}}),

};

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_japanese_json_aee1d0.js.map