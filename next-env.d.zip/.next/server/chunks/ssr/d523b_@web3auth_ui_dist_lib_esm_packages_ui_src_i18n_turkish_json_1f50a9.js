module.exports = {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/turkish.json.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>turkish),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Devam etmek için {{adapter}} hesabınızı doğrula",
    "adapter-loader.message1": "{{adapter}} doğrula",
    "adapter-loader.message2": "devam edecek hesap",
    "errors-invalid-email": "Geçersiz E-posta",
    "errors-invalid-number": "Geçersiz Telefon Numarası",
    "errors-invalid-number-email": "Geçersiz E-posta veya Telefon Numarası",
    "errors-required": "Zorunlu",
    "external.back": "Geri",
    "external.connect": "Cüzdanla devam et",
    "external.search-text": "Cüzdanınızı görmüyor musunuz?",
    "external.search-subtext": "Bunun yerine aramayı deneyin",
    "external.connect-wallet": "Cüzdanı Bağla",
    "external.continue": "Harici cüzdanla devam et",
    "external.dont-have": "Yok",
    "external.get": "Al",
    "external.get-wallet": "Cüzdan Al",
    "external.install-browser-extension": "{{browser}} uzantısını yükle",
    "external.install-mobile-app": "{{os}} uygulamasını yükle",
    "external.installed": "Yüklendi",
    "external.no-wallets-found": "Cüzdan bulunamadı",
    "external.search-wallet": "{{count}} cüzdan ara...",
    "external.title": "Harici Cüzdan",
    "external.walletconnect-connect": "Bağla",
    "external.walletconnect-copy": "WalletConnect destekli bir cüzdanla tarayın veya panonuza kopyalamak için QR kodunu tıklayın.",
    "external.walletconnect-subtitle": "QR kodunu WalletConnect uyumlu bir cüzdanla tarayın",
    "footer.message": "Öz-yönetimli giriş yapan:",
    "footer.message-new": "Kendi kendine velayet",
    "footer.policy": "Gizlilik Politikası",
    "footer.terms": "Kullanım Şartları",
    "footer.terms-service": "Hizmet Şartları",
    "footer.version": "Versiyon",
    "header-subtitle": "Devam etmek için seçeneklerden birini işaretle",
    "header-subtitle-name": "Tek tıklama ile {{appName}} cüzdanınız",
    "header-subtitle-new": "Tek tıklama ile blockchain cüzdanınız",
    "header-title": "Giriş yap",
    "header-tooltip-desc": "Cüzdan, dijital varlıklarınızı blockchain'de saklama ve yönetme görevi görür.",
    "header-tooltip-title": "Cüzdan",
    "network.add-request": "Bu site bir ağ eklemek istiyor",
    "network.cancel": "İptal",
    "network.from": "Nereden",
    "network.proceed": "Devam",
    "network.switch-request": "Bu site ağ değiştirmeyi talep ediyor",
    "network.to": "Nereye",
    "passkey.add": "Passkey ekle",
    "passkey.haveExisting": "Mevcut bir passkey'ınız mı var?",
    "passkey.learn-more": "Daha fazla bilgi edin",
    "passkey.or": "veya",
    "passkey.register-desc": "passkeys ile kimliğinizi yüzünüz, parmak iziniz veya güvenlik anahtarlarınız aracılığıyla doğrulayabilirsiniz.",
    "passkey.register-title": "Passkey'ı kaydedin",
    "passkey.use": "Bir passkey'im var",
    "popup.phone-body": "Ülke kodunuz otomatik olarak algılanacaktır, ancak farklı bir ülkeden bir telefon numarası kullanıyorsanız, doğru ülke kodunu manuel olarak girmeniz gerekir.",
    "popup.phone-header": "Telefon numarası ve ülke kodu",
    "post-loading.connected": "Hesabınızla bağlandınız",
    "post-loading.something-wrong": "Bir şeyler ters gitti!",
    "social.continue": "Devam et: ",
    "social.continueCustom": "{{adapter}} ile devam et",
    "social.email": "E-posta",
    "social.email-continue": "E-posta ile devam et",
    "social.email-new": "isim@ornek.com",
    "social.passwordless-cta": "Devam et",
    "social.passwordless-login": "Giriş yapmak",
    "social.passwordless-title": "E-posta veya Telefon",
    "social.phone": "Telefon",
    "social.policy": "Sosyal medya girişlerinizle ilgili hiçbir veriyi saklamıyoruz.",
    "social.sms": "Mobil Telefon",
    "social.sms-continue": "Telefon ile devam et",
    "social.sms-invalid-number": "Geçersiz telefon numarası",
    "social.sms-placeholder-text": "Örneğin:",
    "social.view-less": "Daha az görüntüle",
    "social.view-less-socials": "Daha az socials görüntüle",
    "social.view-more": "Daha fazla görüntüle",
    "social.view-more-socials": "Daha fazlasını görüntüle socials"
};
var turkish = {
    modal: modal
};
;
}}),

};

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_turkish_json_1f50a9.js.map