module.exports = {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/german.json.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>german),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Bestätigen Sie Ihr {{adapter}}-Konto, um fortzufahren",
    "adapter-loader.message1": "Bestätigen Sie Ihr {{adapter}}",
    "adapter-loader.message2": "Konto fortzusetzen",
    "errors-invalid-email": "Ungültige E-Mail",
    "errors-invalid-number": "Ungültige Telefonnummer",
    "errors-invalid-number-email": "Ungültige E-Mail-Adresse oder Telefonnummer",
    "errors-required": "Erforderlich",
    "external.back": "Zurück",
    "external.connect": "Fahren Sie mit einer Brieftasche fort",
    "external.search-text": "Sie sehen Ihr Portemonnaie nicht?",
    "external.search-subtext": "Versuchen Sie es stattdessen mit der Suche",
    "external.connect-wallet": "Wallet verbinden",
    "external.continue": "Fahren Sie mit der externen Wallet fort",
    "external.dont-have": "Haben nicht",
    "external.get": "Erhalten",
    "external.get-wallet": "Wallet erhalten",
    "external.install-browser-extension": "Installieren Sie die {{browser}}-Erweiterung",
    "external.install-mobile-app": "Installieren Sie die {{os}}-App",
    "external.installed": "Installiert",
    "external.no-wallets-found": "Keine Wallets gefunden",
    "external.search-wallet": "Suche durch {{count}} Geldbörsen...",
    "external.title": "Externe Geldbörse",
    "external.walletconnect-connect": "Verbinden",
    "external.walletconnect-copy": "Scannen Sie mit einem von WalletConnect unterstützten Wallet oder klicken Sie auf den QR-Code, um ihn in Ihre Zwischenablage zu kopieren.",
    "external.walletconnect-subtitle": "Scannen Sie den QR-Code mit einer WalletConnect-kompatiblen Geldbörse",
    "footer.message": "Selbstverwahrungs-Login durch",
    "footer.message-new": "Selbstversorgung über",
    "footer.policy": "Datenschutzrichtlinie",
    "footer.terms": "Nutzungsbedingungen",
    "footer.terms-service": "Nutzungsbedingungen",
    "footer.version": "Versión",
    "header-subtitle": "Wählen Sie eine der folgenden Optionen aus, um fortzufahren",
    "header-subtitle-name": "Ihre {{appName}}-Brieftasche mit einem Klick",
    "header-subtitle-new": "Ihre Blockchain-Brieftasche mit einem Klick",
    "header-title": "Einloggen",
    "header-tooltip-desc": "Die Brieftasche dient als Konto zum Speichern und Verwalten Ihrer digitalen Assets auf der Blockchain.",
    "header-tooltip-title": "Brieftasche",
    "network.add-request": "Diese Website fordert das Hinzufügen eines Netzwerks an",
    "network.cancel": "Abbrechen",
    "network.from": "Von",
    "network.proceed": "Fortfahren",
    "network.switch-request": "Diese Website fordert einen Netzwerkwechsel an",
    "network.to": "Zu",
    "passkey.add": "Passkey hinzufügen",
    "passkey.haveExisting": "Haben Sie bereits einen passkey?",
    "passkey.learn-more": "Erfahren Sie mehr",
    "passkey.or": "oder",
    "passkey.register-desc": "Mit passkeys können Sie Ihre Identität durch Ihr Gesicht, Ihren Fingerabdruck oder Sicherheitsschlüssel überprüfen.",
    "passkey.register-title": "Registrieren Sie Passkey",
    "passkey.use": "Ich habe einen passkey",
    "popup.phone-body": "Ihr Ländercode wird automatisch erkannt, aber wenn Sie eine Telefonnummer aus einem anderen Land verwenden, müssen Sie den richtigen Ländercode manuell eingeben.",
    "popup.phone-header": "Telefonnummer und Ländercode",
    "post-loading.connected": "Sie sind mit Ihrem Konto verbunden",
    "post-loading.something-wrong": "Etwas ist schief gelaufen!",
    "social.continue": "Weitermachen mit",
    "social.continueCustom": "Fahren Sie mit {{adapter}} fort",
    "social.email": "E-Mail",
    "social.email-continue": "Weitermachen mit E-Mail",
    "social.email-new": "name@example.com",
    "social.passwordless-cta": "Weitermachen",
    "social.passwordless-login": "Anmeldung",
    "social.passwordless-title": "E-Mail oder Telefon",
    "social.phone": "Telefon",
    "social.policy": "Wir speichern keine Daten im Zusammenhang mit Ihren Social Logins.",
    "social.sms": "Mobiltelefon",
    "social.sms-continue": "Mit Mobilgerät fortfahren",
    "social.sms-invalid-number": "Ungültige Telefonnummer",
    "social.sms-placeholder-text": "Z.B.:",
    "social.view-less": "Weniger anzeigen",
    "social.view-less-socials": "Weniger anzeigen socials",
    "social.view-more": "Mehr anzeigen",
    "social.view-more-socials": "Weitere socials anzeigen"
};
var german = {
    modal: modal
};
;
}}),

};

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_german_json_3b51d6.js.map