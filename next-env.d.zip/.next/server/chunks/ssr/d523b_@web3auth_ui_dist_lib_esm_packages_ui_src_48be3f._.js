module.exports = {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/config.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AUTH_PROVIDERS": (()=>AUTH_PROVIDERS),
    "AUTH_PROVIDERS_NAMES": (()=>AUTH_PROVIDERS_NAMES),
    "capitalizeFirstLetter": (()=>capitalizeFirstLetter)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/constants.js [app-ssr] (ecmascript)");
;
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}
const restrictedLoginMethods = new Set([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].AUTHENTICATOR,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].PASSKEYS,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].JWT,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].WEBAUTHN
]);
const AUTH_PROVIDERS = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"]).filter((x)=>!restrictedLoginMethods.has(x));
const AUTH_PROVIDERS_NAMES = AUTH_PROVIDERS.reduce((acc, x)=>{
    if (x === "email_passwordless") acc[x] = "Email";
    else if (x === "sms_passwordless") acc[x] = "Mobile";
    else acc[x] = capitalizeFirstLetter(x);
    return acc;
}, {});
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// capture whitelabel only once
__turbopack_esm__({
    "DEFAULT_LOGO_DARK": (()=>DEFAULT_LOGO_DARK),
    "DEFAULT_LOGO_LIGHT": (()=>DEFAULT_LOGO_LIGHT),
    "LOGIN_MODAL_EVENTS": (()=>LOGIN_MODAL_EVENTS),
    "MODAL_STATUS": (()=>MODAL_STATUS),
    "WALLET_CONNECT_LOGO": (()=>WALLET_CONNECT_LOGO)
});
const LOGIN_MODAL_EVENTS = {
    INIT_EXTERNAL_WALLETS: "INIT_EXTERNAL_WALLETS",
    LOGIN: "LOGIN",
    DISCONNECT: "DISCONNECT",
    MODAL_VISIBILITY: "MODAL_VISIBILITY"
};
const MODAL_STATUS = {
    INITIALIZED: "initialized",
    CONNECTED: "connected",
    CONNECTING: "connecting",
    ERRORED: "errored"
};
const DEFAULT_LOGO_LIGHT = "https://images.web3auth.io/web3auth-logo-w.svg"; // logo used on light mode
const DEFAULT_LOGO_DARK = "https://images.web3auth.io/web3auth-logo-w-light.svg"; // logo used on dark mode
const WALLET_CONNECT_LOGO = "https://images.web3auth.io/login-wallet-connect.svg";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/css/web3auth.css.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>css_248z)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$node_modules$2f$style$2d$inject$2f$dist$2f$style$2d$inject$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/node_modules/style-inject/dist/style-inject.es.js [app-ssr] (ecmascript)");
;
var css_248z = "@import url(\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap\");.w3a-parent-container *,.w3a-parent-container :after,.w3a-parent-container :before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:#3b82f680;--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.w3a-parent-container ::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:#3b82f680;--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }\n/*! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com*/.w3a-parent-container *,.w3a-parent-container :after,.w3a-parent-container :before{border:0 solid;box-sizing:border-box}.w3a-parent-container :after,.w3a-parent-container :before{--tw-content:\"\"}.w3a-parent-container :host,.w3a-parent-container html{-webkit-text-size-adjust:100%;font-feature-settings:normal;-webkit-tap-highlight-color:transparent;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-variation-settings:normal;line-height:1.5;-moz-tab-size:4;tab-size:4}.w3a-parent-container body{line-height:inherit;margin:0}.w3a-parent-container hr{border-top-width:1px;color:inherit;height:0}.w3a-parent-container abbr:where([title]){text-decoration:underline dotted}.w3a-parent-container h1,.w3a-parent-container h2,.w3a-parent-container h3,.w3a-parent-container h4,.w3a-parent-container h5,.w3a-parent-container h6{font-size:inherit;font-weight:inherit}.w3a-parent-container a{color:inherit;text-decoration:inherit}.w3a-parent-container b,.w3a-parent-container strong{font-weight:bolder}.w3a-parent-container code,.w3a-parent-container kbd,.w3a-parent-container pre,.w3a-parent-container samp{font-feature-settings:normal;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:1em;font-variation-settings:normal}.w3a-parent-container small{font-size:80%}.w3a-parent-container sub,.w3a-parent-container sup{font-size:75%;line-height:0;position:relative;vertical-align:initial}.w3a-parent-container sub{bottom:-.25em}.w3a-parent-container sup{top:-.5em}.w3a-parent-container table{border-collapse:collapse;border-color:inherit;text-indent:0}.w3a-parent-container button,.w3a-parent-container input,.w3a-parent-container optgroup,.w3a-parent-container select,.w3a-parent-container textarea{font-feature-settings:inherit;color:inherit;font-family:inherit;font-size:100%;font-variation-settings:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;margin:0;padding:0}.w3a-parent-container button,.w3a-parent-container select{text-transform:none}.w3a-parent-container button,.w3a-parent-container input:where([type=button]),.w3a-parent-container input:where([type=reset]),.w3a-parent-container input:where([type=submit]){-webkit-appearance:button;background-color:initial;background-image:none}.w3a-parent-container :-moz-focusring{outline:auto}.w3a-parent-container :-moz-ui-invalid{box-shadow:none}.w3a-parent-container progress{vertical-align:initial}.w3a-parent-container ::-webkit-inner-spin-button,.w3a-parent-container ::-webkit-outer-spin-button{height:auto}.w3a-parent-container [type=search]{-webkit-appearance:textfield;outline-offset:-2px}.w3a-parent-container ::-webkit-search-decoration{-webkit-appearance:none}.w3a-parent-container ::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}.w3a-parent-container summary{display:list-item}.w3a-parent-container blockquote,.w3a-parent-container dd,.w3a-parent-container dl,.w3a-parent-container figure,.w3a-parent-container h1,.w3a-parent-container h2,.w3a-parent-container h3,.w3a-parent-container h4,.w3a-parent-container h5,.w3a-parent-container h6,.w3a-parent-container hr,.w3a-parent-container p,.w3a-parent-container pre{margin:0}.w3a-parent-container fieldset{margin:0;padding:0}.w3a-parent-container legend{padding:0}.w3a-parent-container menu,.w3a-parent-container ol,.w3a-parent-container ul{list-style:none;margin:0;padding:0}.w3a-parent-container dialog{padding:0}.w3a-parent-container textarea{resize:vertical}.w3a-parent-container input::placeholder,.w3a-parent-container textarea::placeholder{color:#9ca3af;opacity:1}.w3a-parent-container [role=button],.w3a-parent-container button{cursor:pointer}.w3a-parent-container :disabled{cursor:default}.w3a-parent-container audio,.w3a-parent-container canvas,.w3a-parent-container embed,.w3a-parent-container iframe,.w3a-parent-container img,.w3a-parent-container object,.w3a-parent-container svg,.w3a-parent-container video{display:block;vertical-align:middle}.w3a-parent-container img,.w3a-parent-container video{height:auto;max-width:100%}.w3a-parent-container [hidden]:where(:not([hidden=until-found])){display:none}.w3a-parent-container{--app-on-primary:#fff;--app-primary-50:#ebf5ff;--app-primary-100:#e1effe;--app-primary-200:#c3ddfd;--app-primary-300:#a4cafe;--app-primary-400:#76a9fa;--app-primary-500:#3f83f8;--app-primary-600:#0346ff;--app-primary-700:#1a56db;--app-primary-800:#1e429f;--app-primary-900:#233876;--app-gray-50:#f9fafb;--app-gray-100:#f3f4f6;--app-gray-200:#e5e7eb;--app-gray-300:#d1d5db;--app-gray-400:#9ca3af;--app-gray-500:#6b7280;--app-gray-600:#4b5563;--app-gray-700:#374151;--app-gray-800:#1f2a37;--app-gray-900:#111928;--app-blue-50:#ebf5ff;--app-blue-100:#e1effe;--app-blue-200:#c3ddfd;--app-blue-300:#a4cafe;--app-blue-400:#76a9fa;--app-blue-500:#3f83f8;--app-blue-600:#0346ff;--app-blue-700:#1a56db;--app-blue-800:#1e429f;--app-blue-900:#233876;--app-red-50:#fdf2f2;--app-red-100:#fde8e8;--app-red-200:#fbd5d5;--app-red-300:#f8b4b4;--app-red-400:#f98080;--app-red-500:#f05252;--app-red-600:#e02424;--app-red-700:#c81e1e;--app-red-800:#9b1c1c;--app-red-900:#771d1d;--app-green-50:#f3faf7;--app-green-100:#def7ec;--app-green-200:#bcf0da;--app-green-300:#84e1bc;--app-green-400:#31c48d;--app-green-500:#0e9f6e;--app-green-600:#057a55;--app-green-700:#046c4e;--app-green-800:#03543f;--app-green-900:#014737;--app-yellow-50:#fdfdea;--app-yellow-100:#fdf6b2;--app-yellow-200:#fce96a;--app-yellow-300:#faca15;--app-yellow-400:#e3a008;--app-yellow-500:#c27803;--app-yellow-600:#9f580a;--app-yellow-700:#8e4b10;--app-yellow-800:#723b13;--app-yellow-900:#633112;--app-success:#30cca4;--app-warning:#fbc94a;--app-error:#fb4a61;--app-info:#d4d4d4;--app-white:#fff;--app-black:#000}.w3a-parent-container .w3a--absolute{position:absolute}.w3a-parent-container .w3a--relative{position:relative}.w3a-parent-container .w3a--left-20{left:5rem}.w3a-parent-container .w3a--left-8{left:2rem}.w3a-parent-container .w3a--left-\\[calc\\(50\\%_-_8px\\)\\]{left:calc(50% - 8px)}.w3a-parent-container .w3a--top-4{top:1rem}.w3a-parent-container .w3a--top-\\[100\\%\\]{top:100%}.w3a-parent-container .w3a--z-20{z-index:20}.w3a-parent-container .w3a--col-span-2{grid-column:span 2/span 2}.w3a-parent-container .w3a--col-span-3{grid-column:span 3/span 3}.w3a-parent-container .w3a--col-span-6{grid-column:span 6/span 6}.w3a-parent-container .w3a--mx-auto{margin-left:auto;margin-right:auto}.w3a-parent-container .w3a--my-4{margin-bottom:1rem;margin-top:1rem}.w3a-parent-container .w3a--my-6{margin-bottom:1.5rem;margin-top:1.5rem}.w3a-parent-container .-w3a--mb-2{margin-bottom:-.5rem}.w3a-parent-container .-w3a--ml-\\[100px\\]{margin-left:-100px}.w3a-parent-container .w3a--mb-1{margin-bottom:.25rem}.w3a-parent-container .w3a--mb-2{margin-bottom:.5rem}.w3a-parent-container .w3a--mb-4{margin-bottom:1rem}.w3a-parent-container .w3a--mb-5{margin-bottom:1.25rem}.w3a-parent-container .w3a--ml-2{margin-left:.5rem}.w3a-parent-container .w3a--ml-\\[3px\\]{margin-left:3px}.w3a-parent-container .w3a--ml-auto{margin-left:auto}.w3a-parent-container .w3a--mr-6{margin-right:1.5rem}.w3a-parent-container .w3a--mr-auto{margin-right:auto}.w3a-parent-container .w3a--mt-4{margin-top:1rem}.w3a-parent-container .w3a--block{display:block}.w3a-parent-container .w3a--flex{display:flex}.w3a-parent-container .w3a--inline-flex{display:inline-flex}.w3a-parent-container .w3a--hidden{display:none}.w3a-parent-container .w3a--h-10{height:2.5rem}.w3a-parent-container .w3a--h-3{height:.75rem}.w3a-parent-container .w3a--h-4{height:1rem}.w3a-parent-container .w3a--h-auto{height:auto}.w3a-parent-container .w3a--h-full{height:100%}.w3a-parent-container .w3a--w-10{width:2.5rem}.w3a-parent-container .w3a--w-3{width:.75rem}.w3a-parent-container .w3a--w-\\[270px\\]{width:270px}.w3a-parent-container .w3a--w-\\[300px\\]{width:300px}.w3a-parent-container .w3a--w-auto{width:auto}.w3a-parent-container .w3a--w-full{width:100%}.w3a-parent-container .w3a--flex-shrink{flex-shrink:1}.w3a-parent-container .w3a--flex-shrink-0{flex-shrink:0}.w3a-parent-container .w3a--flex-grow-0{flex-grow:0}.w3a-parent-container .w3a--translate-x-\\[-16px\\]{--tw-translate-x:-16px}.w3a-parent-container .w3a--rotate-45,.w3a-parent-container .w3a--translate-x-\\[-16px\\]{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.w3a-parent-container .w3a--rotate-45{--tw-rotate:45deg}.w3a-parent-container .w3a--cursor-pointer{cursor:pointer}.w3a-parent-container .w3a--flex-row{flex-direction:row}.w3a-parent-container .w3a--flex-col{flex-direction:column}.w3a-parent-container .w3a--items-center{align-items:center}.w3a-parent-container .\\!w3a--justify-start{justify-content:flex-start!important}.w3a-parent-container .w3a--justify-start{justify-content:flex-start}.w3a-parent-container .w3a--justify-end{justify-content:flex-end}.w3a-parent-container .w3a--justify-center{justify-content:center}.w3a-parent-container .\\!w3a--justify-between{justify-content:space-between!important}.w3a-parent-container .w3a--justify-between{justify-content:space-between}.w3a-parent-container .w3a--gap-1{gap:.25rem}.w3a-parent-container .w3a--gap-2{gap:.5rem}.w3a-parent-container .w3a--gap-3{gap:.75rem}.w3a-parent-container .w3a--gap-y-0\\.5{row-gap:.125rem}.w3a-parent-container .w3a--truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.w3a-parent-container .w3a--rounded{border-radius:.25rem}.w3a-parent-container .w3a--rounded-full{border-radius:9999px}.w3a-parent-container .w3a--rounded-lg{border-radius:.5rem}.w3a-parent-container .w3a--rounded-md{border-radius:.375rem}.w3a-parent-container .w3a--rounded-xl{border-radius:.75rem}.w3a-parent-container .w3a--border-8{border-width:8px}.w3a-parent-container .w3a--border-b-0{border-bottom-width:0}.w3a-parent-container .w3a--border-l-transparent{border-left-color:#0000}.w3a-parent-container .w3a--border-r-transparent{border-right-color:#0000}.w3a-parent-container .w3a--border-t-app-gray-900{border-top-color:var(--app-gray-900)}.w3a-parent-container .w3a--bg-app-gray-50{background-color:var(--app-gray-50)}.w3a-parent-container .w3a--bg-app-primary-100{background-color:var(--app-primary-100)}.w3a-parent-container .w3a--object-contain{object-fit:contain}.w3a-parent-container .w3a--p-4{padding:1rem}.w3a-parent-container .w3a--p-6{padding:1.5rem}.w3a-parent-container .w3a--px-2{padding-left:.5rem;padding-right:.5rem}.w3a-parent-container .w3a--px-3{padding-left:.75rem;padding-right:.75rem}.w3a-parent-container .w3a--py-1{padding-bottom:.25rem;padding-top:.25rem}.w3a-parent-container .w3a--py-2{padding-bottom:.5rem;padding-top:.5rem}.w3a-parent-container .w3a--py-4{padding-bottom:1rem;padding-top:1rem}.w3a-parent-container .w3a--py-6{padding-bottom:1.5rem;padding-top:1.5rem}.w3a-parent-container .w3a--pt-7{padding-top:1.75rem}.w3a-parent-container .w3a--text-left{text-align:left}.w3a-parent-container .w3a--text-center{text-align:center}.w3a-parent-container .w3a--text-right{text-align:right}.w3a-parent-container .w3a--text-sm{font-size:.875rem;line-height:1.25rem}.w3a-parent-container .w3a--text-xs{font-size:.75rem;line-height:1rem}.w3a-parent-container .w3a--font-medium{font-weight:500}.w3a-parent-container .w3a--leading-none{line-height:1}.w3a-parent-container .w3a--text-app-gray-300{color:var(--app-gray-300)}.w3a-parent-container .w3a--text-app-gray-400{color:var(--app-gray-400)}.w3a-parent-container .w3a--text-app-gray-500{color:var(--app-gray-500)}.w3a-parent-container .w3a--text-app-gray-900{color:var(--app-gray-900)}.w3a-parent-container .w3a--text-app-primary-800{color:var(--app-primary-800)}.w3a-parent-container .w3a--text-app-white{color:var(--app-white)}.w3a-parent-container .w3a--shadow-lg{--tw-shadow:0 10px 15px -3px #0000001a,0 4px 6px -4px #0000001a;--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color),0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.w3a-parent-container input[type=number]::-webkit-inner-spin-button,.w3a-parent-container input[type=number]::-webkit-outer-spin-button{appearance:none}@keyframes shake{0%,to{transform:translateX(0)}10%,30%,50%,70%,90%{transform:translateX(-5px)}20%,40%,60%,80%{transform:translateX(5px)}}@keyframes tilt{0%{opacity:0;transform:scale(.9) rotate(0deg)}30%{opacity:1;transform:scale(1.05) rotate(-5deg)}60%{transform:scale(1.05) rotate(5deg)}to{transform:scale(1) rotate(0deg)}}@keyframes open-modal{0%{opacity:0;transform:scale(.8) rotate(-5deg)}60%{opacity:1;transform:scale(1.05) rotate(2deg)}to{transform:scale(1) rotate(0deg)}}@keyframes bounce{0%{opacity:0;transform:scale(.9) translateY(-50%)}30%{opacity:1;transform:scale(1.05) translateY(0)}50%{transform:scale(.95) translateY(-10%)}70%{transform:scale(1.02) translateY(0)}85%{transform:scale(.98) translateY(-5%)}to{transform:scale(1) translateY(0)}}@keyframes subtleAppear{0%{opacity:0;transform:scale(.9)}60%{opacity:1;transform:scale(1.02)}to{transform:scale(1)}}.w3a-parent-container .transition-wrapper{height:100%;position:relative;width:100%}.w3a-parent-container .fade-in{opacity:1;transition:opacity .3s}.w3a-parent-container .fade-out{opacity:0;transition:opacity .3s}.w3a-parent-container .slide-enter{opacity:0;transform:translateX(100%)}.w3a-parent-container .slide-enter-active{opacity:1;transform:translateX(0);transition:transform .3s ease-in-out,opacity .3s ease-in-out}.w3a-parent-container .slide-exit{opacity:1;transform:translateX(0)}.w3a-parent-container .slide-exit-active{opacity:0;transform:translateX(-100%);transition:transform .3s ease-in-out,opacity .3s ease-in-out}.w3a-parent-container .tooltip{--tw-translate-x:-50%;--tw-translate-y:-50%;--tw-shadow:0 4px 6px -1px #0000001a,0 2px 4px -2px #0000001a;--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color),0 2px 4px -2px var(--tw-shadow-color);background-color:var(--app-gray-900);border-radius:.5rem;bottom:58%;box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow);color:var(--app-white);font-size:.875rem;left:50%;line-height:1.25rem;padding:.25rem .5rem;position:absolute;text-align:center;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));width:max-content}.w3a-parent-container #w3a-modal{align-items:center;box-sizing:border-box;display:flex;font-family:Inter;inset:0;justify-content:center;padding:1rem;position:fixed}.w3a-parent-container #w3a-modal.w3a-modal--hidden{display:none}.w3a-parent-container #w3a-modal:before{background-color:var(--app-black);content:\"\";inset:0;opacity:0;position:fixed;transition:opacity .2s ease-in-out}.w3a-parent-container #w3a-modal .w3a-modal__inner{--tw-shadow:0px 4px 16px #00000014;--tw-shadow-colored:0px 4px 16px var(--tw-shadow-color);background-color:var(--app-white);border-color:var(--app-gray-100);border-radius:32px;border-width:1px;box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow);display:flex;flex-direction:column;max-height:95%;max-width:392px;opacity:0;overflow-x:hidden;overflow-y:hidden;position:relative;width:100%}.w3a-parent-container #w3a-modal .w3a-modal__inner:is(.w3a--dark *){background-color:var(--app-gray-800);border-color:var(--app-gray-800)}.w3a-parent-container #w3a-modal .w3a-modal__inner{transform:scale(.8) rotate(-5deg);transform-origin:center center;transition:all .15s cubic-bezier(.92,0,1,.67)}.w3a-parent-container #w3a-modal .w3a-modal__inner.w3a-modal__inner--active{animation:subtleAppear .5s ease-out forwards;opacity:1;transform-origin:center center;transition:none}.w3a-parent-container #w3a-modal.w3a-modal--active:before{opacity:.5}.w3a-parent-container #w3a-modal .w3a-modal__header{padding:0 2rem .5rem;position:relative}.w3a-parent-container #w3a-modal .w3a-modal__content{overflow-y:auto;padding:1rem 2rem}.w3a-parent-container #w3a-modal .w3a-modal__content_external_wallet{overflow-y:auto;padding-left:2rem;padding-right:2rem;padding-top:1.5rem}.w3a-parent-container #w3a-modal .w3a-modal__footer{align-items:center;justify-content:center;margin-top:auto;padding:1rem 2rem;text-align:center}.w3a-parent-container #w3a-modal .w3a-header{align-items:center;display:flex;padding-top:2rem}.w3a-parent-container #w3a-modal .w3a-header__logo{margin-bottom:1rem}.w3a-parent-container #w3a-modal .w3a-header__logo img{height:auto;width:2.5rem}.w3a-parent-container #w3a-modal .w3a-header__title{color:var(--app-gray-900);font-size:1.25rem;font-weight:700;line-height:1.75rem}.w3a-parent-container #w3a-modal .w3a-header__title:is(.w3a--dark *){color:var(--app-white)}.w3a-parent-container #w3a-modal div.w3a-header__subtitle{align-items:center;color:var(--app-gray-500);display:flex;font-size:.875rem;font-weight:400;line-height:1.25rem}.w3a-parent-container #w3a-modal div.w3a-header__subtitle:is(.w3a--dark *){color:var(--app-gray-400)}.w3a-parent-container #w3a-modal div.w3a-header__subtitle img{height:14px;margin-left:.25rem;width:14px}.w3a-parent-container #w3a-modal button.w3a-header__button{align-items:center;border-radius:9999px;border-width:0;cursor:pointer;display:flex;height:1.5rem;justify-content:center;padding:0;position:absolute;right:1.75rem;top:1.7rem;width:1.5rem}.w3a-parent-container #w3a-modal button.w3a-header__button:hover{background-color:var(--app-gray-100)}.w3a-parent-container #w3a-modal button.w3a-header__button:active,.w3a-parent-container #w3a-modal button.w3a-header__button:focus{outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal button.w3a-header__button:hover:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container #w3a-modal button.w3a-header__button:focus:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal button.w3a-header__button:active:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet{align-items:center;border-radius:9999px;border-width:0;cursor:pointer;display:flex;height:1.5rem;justify-content:center;padding:0;position:absolute;right:1.75rem;top:1.6rem;width:1.5rem}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:hover{background-color:var(--app-gray-100)}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:active,.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:focus{outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:hover:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:focus:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal button.w3a-header__button_wallet:active:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal div.w3a-social__policy{color:var(--app-gray-500);font-size:.75rem;font-weight:500;line-height:1rem;margin-top:1rem;text-align:left}.w3a-parent-container #w3a-modal div.w3a-social__policy:is(.w3a--dark *){color:var(--app-gray-400)}.w3a-parent-container #w3a-modal .w3a-group{margin-bottom:1rem}.w3a-parent-container #w3a-modal .w3a-group-loader-height{align-items:center;display:flex;height:200px;justify-content:center}.w3a-parent-container #w3a-modal .w3a-group:last-child{margin-bottom:0}.w3a-parent-container #w3a-modal .w3ajs-passwordless div.w3a-group__title{align-items:center;display:flex}.w3a-parent-container #w3a-modal .w3ajs-passwordless div.w3a-group__title img{height:14px;margin-left:.25rem;width:14px}.w3a-parent-container #w3a-modal .w3a-group.w3a-group--email-hidden,.w3a-parent-container #w3a-modal .w3a-group.w3a-group--ext-wallet-hidden,.w3a-parent-container #w3a-modal .w3a-group.w3a-group--hidden,.w3a-parent-container #w3a-modal .w3a-group.w3a-group--social-hidden{display:none}.w3a-parent-container #w3a-modal div.w3a-group__title{color:var(--app-gray-900);font-size:.875rem;font-weight:500;line-height:1.25rem;margin-bottom:.5rem}.w3a-parent-container #w3a-modal div.w3a-group__title:is(.w3a--dark *){color:var(--app-white)}.w3a-parent-container #w3a-modal div.w3a-adapter-list-container{height:362px;overflow-y:auto;scrollbar-width:none}.w3a-parent-container #w3a-modal ul.w3a-adapter-list{display:grid;gap:8px;grid-template-columns:repeat(6,minmax(0,1fr));max-height:500px;overflow-y:auto;padding:1px;scrollbar-width:none;transition:max-height .35s;transition-timing-function:cubic-bezier(.92,0,.74,1)}.w3a-parent-container #w3a-modal ul.w3a-adapter-list.w3a-adapter-list--shrink{max-height:100px;overflow-y:hidden;transition:max-height .3s;transition-timing-function:cubic-bezier(0,.73,.71,1)}.w3a-parent-container #w3a-modal ul.w3a-adapter-list.w3a-adapter-list--hidden{display:none}.w3a-parent-container #w3a-modal li.w3a-adapter-item{list-style-type:none}.w3a-parent-container #w3a-modal li.w3a-adapter-item--full{grid-column:span 6/span 6}.w3a-parent-container #w3a-modal .w3a-adapter-item--hide{display:none}.w3a-parent-container #w3a-modal .w3a-external-toggle{display:block;width:100%!important}.w3a-parent-container #w3a-modal .w3a-external-toggle.w3a-external-toggle--hidden{display:none}.w3a-parent-container #w3a-modal .w3a-external-container{display:block;margin-bottom:0}.w3a-parent-container #w3a-modal .w3a-external-container.w3a-external-container--hidden{display:none}.w3a-parent-container #w3a-modal .w3a-external-group{display:flex;flex-wrap:wrap;gap:.75rem;margin-bottom:1rem}.w3a-parent-container #w3a-modal .w3a-external-group__left{flex-grow:1}.w3a-parent-container #w3a-modal button.w3a-external-back{align-items:center;background-image:none;border-radius:9999px;border-width:0;color:var(--app-gray-500);cursor:pointer;display:flex;height:1.5rem;justify-content:center;padding:0;width:1.5rem}.w3a-parent-container #w3a-modal button.w3a-external-back:hover{background-color:var(--app-gray-100);color:var(--app-gray-900)}.w3a-parent-container #w3a-modal button.w3a-external-back:active,.w3a-parent-container #w3a-modal button.w3a-external-back:focus{outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal button.w3a-external-back:is(.w3a--dark *){color:var(--app-gray-400)}.w3a-parent-container #w3a-modal button.w3a-external-back:hover:is(.w3a--dark *){background-color:var(--app-gray-700);color:var(--app-white)}.w3a-parent-container #w3a-modal button.w3a-external-back:focus:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal button.w3a-external-back:active:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-external-back .w3a-group__title{color:var(--app-gray-400);margin-bottom:0;margin-left:5px}.w3a-parent-container #w3a-modal .w3a-external-loader{display:flex;justify-content:center}.w3a-parent-container #w3a-modal .w3a-wallet-connect{display:block;margin-bottom:.625rem;text-align:center}.w3a-parent-container #w3a-modal .w3a-wallet-connect.w3a-wallet-connect--hidden{display:none}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container{background-color:var(--app-white);border-radius:10px;color:var(--app-gray-500);font-size:.625rem;margin-left:auto;margin-right:auto;min-width:250px;padding-bottom:.625rem;padding-top:.625rem;width:fit-content}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container:is(.w3a--dark *){background-color:var(--app-gray-800);color:var(--app-gray-400)}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container-android,.w3a-parent-container #w3a-modal .w3a-wallet-connect__container-desktop{margin:auto}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container-btn-group{display:flex;gap:18px}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container-ios{box-sizing:border-box;column-gap:1.25rem;display:flex;flex-wrap:wrap;padding:0 0 1.75rem;row-gap:30px}.w3a-parent-container #w3a-modal .w3a-wallet-connect-qr>canvas,.w3a-parent-container #w3a-modal .w3a-wallet-connect-qr>svg{margin:auto}.w3a-parent-container #w3a-modal .w3a-wallet-connect__container-android a{text-decoration-line:none}.w3a-parent-container #w3a-modal .w3a-wallet-connect__logo>img{margin:0 auto 1rem;width:115px}.w3a-parent-container #w3a-modal .w3a-footer{align-items:center;color:var(--app-gray-400);display:flex;font-size:.75rem;justify-content:center;line-height:1rem}.w3a-parent-container #w3a-modal .w3a-footer__links a:active,.w3a-parent-container #w3a-modal .w3a-footer__links a:focus{outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal .w3a-footer__links a:focus:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-footer__links a:active:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-footer__links span{margin:0 4px}.w3a-parent-container #w3a-modal.w3a-modal--light .w3a-footer__links a:focus-visible{outline:1px solid #0f1222}.w3a-parent-container #w3a-modal.w3a-modal--light .w3a-external-back:focus-visible{outline:1px solid #0f1222}.w3a-parent-container #w3a-modal .hover-icon{display:none;transition:display .15s;transition-timing-function:cubic-bezier(0,.54,.63,.99)}.w3a-parent-container #w3a-modal .w3a-text-field{background-color:var(--app-gray-50);border-color:var(--app-gray-300);border-radius:9999px;border-width:1px;color:var(--app-gray-900);font-size:.875rem;line-height:1.25rem;margin-top:.5rem;padding:.75rem 1.5rem}.w3a-parent-container #w3a-modal .w3a-text-field::placeholder{color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .w3a-text-field{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000);outline-width:0}.w3a-parent-container #w3a-modal .w3a-text-field:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);border-color:#0000;box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .w3a-text-field:disabled{cursor:not-allowed}.w3a-parent-container #w3a-modal .w3a-text-field:disabled::placeholder{color:var(--app-gray-400)}.w3a-parent-container #w3a-modal .w3a-text-field:is(.w3a--dark *){background-color:var(--app-gray-600);border-color:var(--app-gray-500);color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-text-field:is(.w3a--dark *)::placeholder{color:var(--app-gray-400)}.w3a-parent-container #w3a-modal .w3a-text-field:focus:is(.w3a--dark *){--tw-ring-color:var(--app-primary-500);border-color:#0000}.w3a-parent-container #w3a-modal .w3a-text-field:disabled:is(.w3a--dark *)::placeholder{color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .w3a-text-field{line-height:1.25em}.w3a-parent-container #w3a-modal .w3a-text-field--country-code{display:flex;justify-content:space-between;padding-left:1rem;padding-right:1rem;width:100%}.w3a-parent-container #w3a-modal .w3a-text-field--number{appearance:none}.w3a-parent-container #w3a-modal .w3a-sms-field--error{color:var(--app-red-500);font-size:.875rem;line-height:1.25rem;margin-bottom:.5rem;margin-left:.375rem;margin-top:-.5rem}.w3a-parent-container #w3a-container #w3a-modal input.w3a-text-field:-webkit-autofill,.w3a-parent-container #w3a-container #w3a-modal input.w3a-text-field:-webkit-autofill:active,.w3a-parent-container #w3a-container #w3a-modal input.w3a-text-field:-webkit-autofill:focus,.w3a-parent-container #w3a-container #w3a-modal input.w3a-text-field:-webkit-autofill:hover{--tw-shadow:0 0 0 30px #f9fafb inset;--tw-shadow-colored:inset 0 0 0 30px var(--tw-shadow-color);-webkit-text-fill-color:#111928!important;box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.w3a-parent-container #w3a-container.dark #w3a-modal input.w3a-text-field:-webkit-autofill,.w3a-parent-container #w3a-container.dark #w3a-modal input.w3a-text-field:-webkit-autofill:active,.w3a-parent-container #w3a-container.dark #w3a-modal input.w3a-text-field:-webkit-autofill:focus,.w3a-parent-container #w3a-container.dark #w3a-modal input.w3a-text-field:-webkit-autofill:hover{--tw-shadow:0 0 0 30px #374151 inset;--tw-shadow-colored:inset 0 0 0 30px var(--tw-shadow-color);-webkit-text-fill-color:#fff!important;box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.w3a-parent-container #w3a-modal .w3a-button{background-color:var(--app-gray-100);border-radius:9999px;color:var(--app-gray-900);font-size:1rem;font-weight:500;line-height:1.5rem;padding:.75rem 1.5rem}.w3a-parent-container #w3a-modal .w3a-button:hover{background-color:var(--app-gray-300)}.w3a-parent-container #w3a-modal .w3a-button:focus{background-color:var(--app-gray-100);color:var(--app-gray-700);outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal .w3a-button:active{outline-color:var(--app-gray-50)}.w3a-parent-container #w3a-modal .w3a-button:disabled{background-color:var(--app-gray-50);color:var(--app-gray-300)}.w3a-parent-container #w3a-modal .w3a-button:is(.w3a--dark *){background-color:var(--app-gray-900);color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-button:hover:is(.w3a--dark *){background-color:var(--app-gray-800)}.w3a-parent-container #w3a-modal .w3a-button:focus:is(.w3a--dark *){background-color:var(--app-gray-900);color:var(--app-white);outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-button:active:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-button:disabled:is(.w3a--dark *){--tw-bg-opacity:1;background-color:rgb(59 69 85/var(--tw-bg-opacity,1));color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .w3a-button--primary{background-color:var(--app-primary-600);color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-button--primary:hover{background-color:var(--app-primary-800)}.w3a-parent-container #w3a-modal .w3a-button--primary:focus{background-color:var(--app-primary-600);color:var(--app-white);outline-color:var(--app-primary-300)}.w3a-parent-container #w3a-modal .w3a-button--primary:active{outline-color:var(--app-primary-300)}.w3a-parent-container #w3a-modal .w3a-button--primary:disabled{--tw-text-opacity:1;background-color:var(--app-primary-200);color:rgb(235 245 255/var(--tw-text-opacity,1))}.w3a-parent-container #w3a-modal .w3a-button--primary:is(.w3a--dark *){background-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .w3a-button--primary:hover:is(.w3a--dark *){background-color:var(--app-primary-800)}.w3a-parent-container #w3a-modal .w3a-button--primary:focus:is(.w3a--dark *){background-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .w3a-button--primary:disabled:is(.w3a--dark *){--tw-bg-opacity:1;background-color:rgb(45 72 116/var(--tw-bg-opacity,1));color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .w3a-button--login{align-items:center;display:inline-flex;height:2.75rem;justify-content:center}.w3a-parent-container #w3a-modal button.w3a-button--login:hover>.hover-icon{display:block;transition:display .15s;transition-timing-function:cubic-bezier(0,.54,.63,.99)}.w3a-parent-container #w3a-modal button.w3a-button--login:hover>.image-icon{display:none;transition:display .15s;transition-timing-function:cubic-bezier(0,.54,.63,.99)}.w3a-parent-container #w3a-modal button.w3a-button-expand{color:var(--app-primary-600);font-size:.875rem;height:auto;line-height:1.25rem;margin-left:auto;margin-top:1rem;width:auto}.w3a-parent-container #w3a-modal button.w3a-button-expand:hover{color:var(--app-primary-800)}.w3a-parent-container #w3a-modal button.w3a-button-expand:focus-visible{outline-color:var(--app-gray-50);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal button.w3a-button-expand:is(.w3a--dark *){color:var(--app-primary-500)}.w3a-parent-container #w3a-modal button.w3a-button-expand:hover:is(.w3a--dark *){color:var(--app-primary-400)}.w3a-parent-container #w3a-modal button.w3a-button-expand:focus-visible:is(.w3a--dark *){outline-color:var(--app-gray-400);outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .w3a-sms-field__container{display:grid;gap:.5rem;grid-template-columns:repeat(12,minmax(0,1fr))}.w3a-parent-container #w3a-modal .w3a-sms-field__code-selected{display:flex}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown{height:185px;position:absolute;width:120px;z-index:10}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown>:not([hidden])~:not([hidden]){--tw-divide-y-reverse:0;border-bottom-width:calc(1px*var(--tw-divide-y-reverse));border-color:var(--app-gray-100);border-top-width:calc(1px*(1 - var(--tw-divide-y-reverse)))}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown{--tw-shadow:0px 4px 16px #00000014;--tw-shadow-colored:0px 4px 16px var(--tw-shadow-color);background-color:var(--app-white);border-radius:.5rem;box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow);overflow-y:scroll}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown{transform:translateY(-230px)}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown--hidden{display:none}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown ul{color:var(--app-gray-700);font-size:.875rem;line-height:1.25rem;padding-bottom:.5rem;padding-top:.5rem}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown ul:is(.w3a--dark *){color:var(--app-gray-200)}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown li{cursor:pointer;padding:0}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown li:hover{background-color:var(--app-gray-100)}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown li:hover:is(.w3a--dark *){background-color:var(--app-gray-900);color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown li button{height:100%;padding:.5rem 1rem;text-align:left;width:100%}.w3a-parent-container #w3a-modal .w3a-sms-field__code-dropdown li button div{align-items:center;display:flex}.w3a-parent-container #w3a-modal .w3a-sms-field__code{grid-column:span 5/span 5}.w3a-parent-container #w3a-modal .w3a-sms-field__number{grid-column:span 7/span 7}.w3a-parent-container #w3a-modal .w3a-modal__loader{background-color:var(--app-white);display:flex;inset:0;justify-content:center;position:absolute;z-index:10}.w3a-parent-container #w3a-modal .w3a-modal__loader:is(.w3a--dark *){background-color:var(--app-gray-800)}.w3a-parent-container #w3a-modal .w3a-modal__loader.w3a-modal__loader--hidden{display:none}.w3a-parent-container #w3a-modal .w3a-modal__loader-content{display:flex;flex-direction:column;position:relative;text-align:center}.w3a-parent-container #w3a-modal .w3a-modal__loader-info{align-items:center;display:flex;flex-direction:column;flex-grow:1;justify-content:center;padding:0 30px}.w3a-parent-container #w3a-modal .w3a-spinner-label{color:var(--app-primary-600);font-size:1rem;font-weight:500;line-height:1.5rem;margin-top:10px}.w3a-parent-container #w3a-modal .w3a-spinner-label:is(.w3a--dark *){color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .w3a-spinner-message{color:var(--app-gray-500);font-size:1rem;line-height:1.5rem;margin-top:10px}.w3a-parent-container #w3a-modal .w3a-spinner-message:first-letter{text-transform:capitalize}.w3a-parent-container #w3a-modal .w3a-spinner-message:is(.w3a--dark *){color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-spinner-message.w3a-spinner-message--error{color:var(--app-red-500)}.w3a-parent-container #w3a-modal .w3a-spinner-power{--tw-text-opacity:1;color:rgb(183 184 189/var(--tw-text-opacity,1));font-size:.75rem;line-height:1rem;margin-top:auto}.w3a-parent-container #w3a-modal .w3a-spinner-power>img{display:inline;height:2rem;width:auto}.w3a-parent-container #w3a-modal .w3a-spinner{display:inline-flex;height:60px;position:relative;width:60px}.w3a-parent-container #w3a-modal .w3a-spinner__spinner{position:absolute}@keyframes w3a--spin{to{transform:rotate(1turn)}}.w3a-parent-container #w3a-modal .w3a-spinner__spinner{animation:w3a--spin 1s linear infinite;background-image:conic-gradient(from 0deg at 50% 50%,var(--app-primary-600) 0,#e5e7ebcc 90deg,#e5e7ebcc 270deg,var(--app-primary-600) 1turn);background-position:0 0;background-size:100% 100%;border-radius:100vw;display:inline-block;height:100%;-webkit-mask:radial-gradient(farthest-side,#000 98%,#0000) center/85% 85% no-repeat,linear-gradient(#000 0 0);-webkit-mask-composite:destination-out;mask:radial-gradient(farthest-side,#000 98%,#0000) center/85% 85% no-repeat,linear-gradient(#000 0 0);mask-composite:exclude;width:100%}.w3a-parent-container .dark #w3a-modal .w3a-spinner__spinner{background-image:conic-gradient(from 0deg at 50% 50%,var(--app-primary-500) 0,#e5e7eb33 90deg,#e5e7eb33 270deg,var(--app-primary-500) 1turn)}.w3a-parent-container #w3a-modal .w3a-modal__loader-bridge{align-items:center;display:flex;justify-content:center;margin-bottom:14px}.w3a-parent-container #w3a-modal .w3a-modal__loader-bridge-message{color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .w3a-modal__loader-bridge-message:first-letter{text-transform:capitalize}.w3a-parent-container #w3a-modal .w3a-modal__loader-bridge-message:is(.w3a--dark *){color:var(--app-white)}.w3a-parent-container #w3a-modal .w3a-modal__loader-app-logo{display:flex;padding:.5rem}.w3a-parent-container #w3a-modal .w3a-modal__loader-app-logo img{height:3rem;max-height:3rem;max-width:3rem;object-fit:contain;width:3rem}.w3a-parent-container #w3a-modal .w3a-modal__loader-social-logo{align-items:center;border-radius:9999px;display:flex;height:3.5rem;justify-content:center;padding:.25rem;width:3.5rem}.w3a-parent-container #w3a-modal .w3a-modal__loader-social-logo img{height:2.5rem;max-height:2.5rem;max-width:2.5rem;object-fit:contain;width:2.5rem}.w3a-parent-container #w3a-modal .w3a-modal__loader-adapter img{height:auto;width:84px}.w3a-parent-container #w3a-modal .w3a-modal__connector{align-items:center;display:flex}.w3a-parent-container .w3a-modal__connector-beat{display:inline-block;height:80px;position:relative;width:80px}.w3a-parent-container .w3a-modal__connector-beat div{animation-timing-function:cubic-bezier(0,1,1,0);background:grey;border-radius:50%;height:13px;position:absolute;top:33px;width:13px}@keyframes w3a--pulse{50%{opacity:.5}}.w3a-parent-container .w3a-modal__connector-beat div{animation:w3a--pulse 2s cubic-bezier(.4,0,.6,1) infinite;background-color:var(--app-gray-200)}.w3a-parent-container .w3a-modal__connector-beat div:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container .w3a-modal__connector-beat div:first-child{animation:beat1 2.4s infinite;left:8px}.w3a-parent-container .w3a-modal__connector-beat div:nth-child(2){animation:beat2 2.4s infinite;left:8px}.w3a-parent-container .w3a-modal__connector-beat div:nth-child(3){animation:beat3 2.4s infinite;left:8px}.w3a-parent-container .w3a-modal__connector-beat div:nth-child(4){animation:beat4 2.4s infinite;left:32px}.w3a-parent-container .w3a-modal__connector-beat div:nth-child(5){animation:beat5 2.4s infinite;left:56px}.w3a-parent-container .wallet-btn{background-color:var(--app-gray-100)}.w3a-parent-container .wallet-btn:hover{background-color:var(--app-gray-200)}.w3a-parent-container .wallet-btn:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container .wallet-btn:hover:is(.w3a--dark *){background-color:var(--app-gray-800)}.w3a-parent-container .wallet-link-btn{color:var(--app-gray-900)}.w3a-parent-container .wallet-link-btn:is(.w3a--dark *){background-color:var(--app-gray-700);color:var(--app-white)}.w3a-parent-container .wallet-link-btn:hover:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container .wallet-link-btn img{height:1.75rem;width:1.75rem}.w3a-parent-container .wallet-adapter-container{height:551px}@keyframes beat1{0%{transform:scale(0)}25%{transform:scale(0)}50%{transform:scale(1)}75%{transform:scale(0)}to{transform:scale(0)}}@keyframes beat2{0%{transform:scale(0)}25%{transform:scale(1)}50%{transform:translate(24px)}75%{transform:translate(0)}to{transform:translate(0) scale(0)}}@keyframes beat3{0%{transform:translate(0)}25%{transform:translate(24px)}50%{transform:translate(48px)}75%{transform:translate(24px)}to{transform:translate(0)}}@keyframes beat4{0%{transform:translate(0)}25%{transform:translate(24px)}50%{transform:translate(24px) scale(0)}75%{transform:translate(24px) scale(1)}to{transform:translate(0)}}@keyframes beat5{0%{transform:scale(1)}25%{transform:scale(0)}50%{transform:scale(0)}75%{transform:scale(0)}to{transform:scale(1)}}.w3a-parent-container .w3a--group:hover .group-hover\\:w3a--flex{display:flex}.w3a-parent-container .dark\\:w3a--block:is(.w3a--dark *){display:block}.w3a-parent-container .dark\\:w3a--hidden:is(.w3a--dark *){display:none}.w3a-parent-container .dark\\:w3a--bg-app-gray-600:is(.w3a--dark *){background-color:var(--app-gray-600)}.w3a-parent-container .dark\\:w3a--bg-app-gray-700:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container .dark\\:w3a--text-app-gray-400:is(.w3a--dark *){color:var(--app-gray-400)}.w3a-parent-container .dark\\:w3a--text-app-gray-500:is(.w3a--dark *){color:var(--app-gray-500)}.w3a-parent-container .dark\\:w3a--text-app-white:is(.w3a--dark *){color:var(--app-white)}";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$node_modules$2f$style$2d$inject$2f$dist$2f$style$2d$inject$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(css_248z);
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/english.json.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>en),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Verify your {{adapter}} account to continue",
    "adapter-loader.message1": "Verify your {{adapter}}",
    "adapter-loader.message2": "account to continue",
    "errors-invalid-email": "Invalid Email",
    "errors-invalid-number": "Invalid Phone Number",
    "errors-invalid-number-email": "Invalid Email or Phone Number",
    "errors-required": "Required",
    "external.back": "Back",
    "external.connect": "Continue with a wallet",
    "external.search-text": "Don't see your wallet?",
    "external.search-subtext": "Try search instead",
    "external.connect-wallet": "Connect Wallet",
    "external.continue": "Continue with external wallet",
    "external.dont-have": "Don't have",
    "external.get": "Get",
    "external.get-wallet": "Get Wallet",
    "external.install-browser-extension": "Install {{browser}} extension",
    "external.install-mobile-app": "Install {{os}} app",
    "external.installed": "Installed",
    "external.no-wallets-found": "No wallets found",
    "external.search-wallet": "Search through {{count}} wallets...",
    "external.title": "External Wallet",
    "external.walletconnect-connect": "Connect",
    "external.walletconnect-copy": "Scan with a WalletConnect-supported wallet or click the QR code to copy to your clipboard.",
    "external.walletconnect-subtitle": "Scan the QR code with a WalletConnect-compatible wallet",
    "footer.message": "Self-custodial login by",
    "footer.message-new": "Self-custody via",
    "footer.policy": "Privacy Policy",
    "footer.terms": "Terms of Use",
    "footer.terms-service": "Terms of Service",
    "footer.version": "Version",
    "header-subtitle": "Select one of the following options to continue",
    "header-subtitle-name": "Your {{appName}} wallet with one click",
    "header-subtitle-new": "Your blockchain wallet with one click",
    "header-title": "Sign in",
    "header-tooltip-desc": "The wallet serves as an account to store and manage your digital assets on the blockchain.",
    "header-tooltip-title": "Wallet",
    "network.add-request": "This site is requesting to add a network",
    "network.cancel": "Cancel",
    "network.from": "From",
    "network.proceed": "Proceed",
    "network.switch-request": "This site is requesting to switch networks",
    "network.to": "To",
    "passkey.add": "Add Passkey",
    "passkey.haveExisting": "Have an existing passkey?",
    "passkey.learn-more": "Learn more",
    "passkey.or": "or",
    "passkey.register-desc": "With passkeys, you can verify your identity through your face, fingerprint, or security keys.",
    "passkey.register-title": "Register Passkey",
    "passkey.use": "I have a passkey",
    "popup.phone-body": "Your country code will be detected automatically, but if you're using a phone number from a different country, you'll need to enter the correct country code manually.",
    "popup.phone-header": "Phone number and country code",
    "post-loading.connected": "You are connected with your account",
    "post-loading.something-wrong": "Something went wrong!",
    "social.continue": "Continue with",
    "social.continueCustom": "Continue with {{adapter}}",
    "social.email": "Email",
    "social.email-continue": "Continue with Email",
    "social.email-new": "name@example.com",
    "social.passwordless-cta": "Continue",
    "social.passwordless-login": "Login",
    "social.passwordless-title": "Email or Phone",
    "social.phone": "Phone",
    "social.policy": "We do not store any data related to your social logins.",
    "social.sms": "Mobile",
    "social.sms-continue": "Continue with Mobile",
    "social.sms-invalid-number": "Invalid phone number",
    "social.sms-placeholder-text": "E.g.:",
    "social.view-less": "View less",
    "social.view-less-socials": "View less socials",
    "social.view-more": "View more",
    "social.view-more-socials": "View more socials"
};
var en = {
    modal: modal
};
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>i18nInstance)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$i18next$2f$dist$2f$esm$2f$i18next$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/i18next/dist/esm/i18next.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$i18n$2f$english$2e$json$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/english.json.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$initReactI18next$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/initReactI18next.js [app-ssr] (ecmascript)");
;
;
;
const i18nInstance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$i18next$2f$dist$2f$esm$2f$i18next$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createInstance();
i18nInstance.use(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$initReactI18next$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["initReactI18next"]).init({
    resources: {
        en: {
            translation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$i18n$2f$english$2e$json$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
        }
    },
    lng: "en",
    fallbackLng: "en",
    interpolation: {
        escapeValue: false
    },
    debug: false,
    react: {
        useSuspense: true
    }
});
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/arrow-left-dark.svg.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ArrowDark)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
var ArrowDark = "data:image/svg+xml,%3Csvg%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cpath%20d%3D%22M8.33333%2015.8333L2.5%209.99992M2.5%209.99992L8.33333%204.16659M2.5%209.99992L17.5%209.99992%22%20stroke%3D%22%239CA3AF%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%3C%2Fsvg%3E";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/arrow-left-light.svg.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ArrowLight)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
var ArrowLight = "data:image/svg+xml,%3Csvg%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cpath%20d%3D%22M8.33333%2015.8333L2.5%209.99995M2.5%209.99995L8.33333%204.16662M2.5%209.99995L17.5%209.99995%22%20stroke%3D%22%236B7280%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%3C%2Fsvg%3E";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/x-dark.svg.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>XDark)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
var XDark = "data:image/svg+xml,%3Csvg%20width%3D%2213%22%20height%3D%2213%22%20viewBox%3D%220%200%2013%2013%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20clip-rule%3D%22evenodd%22%20d%3D%22M0.292787%201.29299C0.480314%201.10552%200.734622%201.0002%200.999786%201.0002C1.26495%201.0002%201.51926%201.10552%201.70679%201.29299L5.99979%205.58599L10.2928%201.29299C10.385%201.19748%2010.4954%201.1213%2010.6174%201.06889C10.7394%201.01648%2010.8706%200.988893%2011.0034%200.987739C11.1362%200.986585%2011.2678%201.01189%2011.3907%201.06217C11.5136%201.11245%2011.6253%201.1867%2011.7192%201.28059C11.8131%201.37449%2011.8873%201.48614%2011.9376%201.60904C11.9879%201.73193%2012.0132%201.86361%2012.012%201.99639C12.0109%202.12917%2011.9833%202.26039%2011.9309%202.38239C11.8785%202.5044%2011.8023%202.61474%2011.7068%202.70699L7.41379%206.99999L11.7068%2011.293C11.8889%2011.4816%2011.9897%2011.7342%2011.9875%2011.9964C11.9852%2012.2586%2011.88%2012.5094%2011.6946%2012.6948C11.5092%2012.8802%2011.2584%2012.9854%2010.9962%2012.9877C10.734%2012.9899%2010.4814%2012.8891%2010.2928%2012.707L5.99979%208.41399L1.70679%2012.707C1.51818%2012.8891%201.26558%2012.9899%201.00339%2012.9877C0.741188%2012.9854%200.490376%2012.8802%200.304968%2012.6948C0.11956%2012.5094%200.0143906%2012.2586%200.0121121%2011.9964C0.00983372%2011.7342%200.110629%2011.4816%200.292787%2011.293L4.58579%206.99999L0.292787%202.70699C0.105316%202.51946%200%202.26515%200%201.99999C0%201.73483%200.105316%201.48052%200.292787%201.29299V1.29299Z%22%20fill%3D%22%239CA3AF%22%2F%3E%3C%2Fsvg%3E";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/x-light.svg.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>XLight)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
var XLight = "data:image/svg+xml,%3Csvg%20width%3D%2213%22%20height%3D%2213%22%20viewBox%3D%220%200%2013%2013%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20clip-rule%3D%22evenodd%22%20d%3D%22M0.292787%201.29299C0.480314%201.10552%200.734622%201.0002%200.999786%201.0002C1.26495%201.0002%201.51926%201.10552%201.70679%201.29299L5.99979%205.58599L10.2928%201.29299C10.385%201.19748%2010.4954%201.1213%2010.6174%201.06889C10.7394%201.01648%2010.8706%200.988893%2011.0034%200.987739C11.1362%200.986585%2011.2678%201.01189%2011.3907%201.06217C11.5136%201.11245%2011.6253%201.1867%2011.7192%201.28059C11.8131%201.37449%2011.8873%201.48614%2011.9376%201.60904C11.9879%201.73193%2012.0132%201.86361%2012.012%201.99639C12.0109%202.12917%2011.9833%202.26039%2011.9309%202.38239C11.8785%202.5044%2011.8023%202.61474%2011.7068%202.70699L7.41379%206.99999L11.7068%2011.293C11.8889%2011.4816%2011.9897%2011.7342%2011.9875%2011.9964C11.9852%2012.2586%2011.88%2012.5094%2011.6946%2012.6948C11.5092%2012.8802%2011.2584%2012.9854%2010.9962%2012.9877C10.734%2012.9899%2010.4814%2012.8891%2010.2928%2012.707L5.99979%208.41399L1.70679%2012.707C1.51818%2012.8891%201.26558%2012.9899%201.00339%2012.9877C0.741188%2012.9854%200.490376%2012.8802%200.304968%2012.6948C0.11956%2012.5094%200.0143906%2012.2586%200.0121121%2011.9964C0.00983372%2011.7342%200.110629%2011.4816%200.292787%2011.293L4.58579%206.99999L0.292787%202.70699C0.105316%202.51946%200%202.26515%200%201.99999C0%201.73483%200.105316%201.48052%200.292787%201.29299V1.29299Z%22%20fill%3D%22%236B7280%22%2F%3E%3C%2Fsvg%3E";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Icon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$arrow$2d$left$2d$dark$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/arrow-left-dark.svg.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$arrow$2d$left$2d$light$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/arrow-left-light.svg.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$x$2d$dark$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/x-dark.svg.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$x$2d$light$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/assets/x-light.svg.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
;
;
;
const icons = {
    "arrow-left": {
        image: "https://images.web3auth.io/circle-arrow-left.svg"
    },
    close: {
        image: "https://images.web3auth.io/close.svg"
    },
    "expand-light": {
        image: "https://images.web3auth.io/expand-light.svg"
    },
    expand: {
        image: "https://images.web3auth.io/expand.svg"
    },
    connected: {
        image: "https://images.web3auth.io/connected.svg"
    },
    "information-circle-light": {
        image: "https://images.web3auth.io/information-circle-light.svg"
    },
    "information-circle": {
        image: "https://images.web3auth.io/information-circle.svg"
    },
    "arrow-left-light": {
        image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$arrow$2d$left$2d$light$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    },
    "x-light": {
        image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$x$2d$light$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    },
    "arrow-left-dark": {
        image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$arrow$2d$left$2d$dark$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    },
    "x-dark": {
        image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$assets$2f$x$2d$dark$2e$svg$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    }
};
function Icon(props) {
    const { iconName, iconTitle = "", height = "auto", width = "auto", darkIconName = "" } = props;
    const h = height === "auto" ? "w3a--h-auto" : `w3a--h-[${height}px]`;
    const w = width === "auto" ? "w3a--w-auto" : `w3a--w-[${width}px]`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            icons[iconName] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                className: `${iconTitle ? "w3a--cursor-pointer" : ""} dark:w3a--hidden w3a--block ${h} ${w}`,
                height: height,
                width: width,
                src: icons[iconName].image,
                alt: iconName,
                title: iconTitle
            }),
            icons[darkIconName] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                className: `${iconTitle ? "w3a--cursor-pointer" : ""} w3a--hidden dark:w3a--block ${h} ${w}`,
                height: height,
                width: width,
                src: icons[darkIconName].image,
                alt: darkIconName,
                title: iconTitle
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/context/ThemeContext.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ThemedContext": (()=>ThemedContext)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
const ThemedContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({
    isDark: true // default value
});
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Image.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Image)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/context/ThemeContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
;
function Image(props) {
    const { hoverImageId, darkHoverImageId, imageId, darkImageId, isButton = false, height = "auto", width = "auto", fallbackImageId, extension = "svg" } = props;
    const { isDark } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemedContext"]);
    const imgName = isDark && darkImageId ? darkImageId : imageId;
    const hoverImgName = isDark && darkHoverImageId ? darkHoverImageId : hoverImageId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                src: `https://images.web3auth.io/${imgName}.${extension}`,
                height: height,
                width: width,
                alt: imageId,
                className: "image-icon w3a--object-contain w3a--rounded",
                onError: ({ currentTarget })=>{
                    if (fallbackImageId) {
                        // eslint-disable-next-line no-param-reassign
                        currentTarget.onerror = null; // prevents looping
                        // eslint-disable-next-line no-param-reassign
                        currentTarget.src = `https://images.web3auth.io/${fallbackImageId}.svg`;
                    }
                }
            }),
            isButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                src: `https://images.web3auth.io/${hoverImgName}.${extension}`,
                height: height,
                width: width,
                alt: hoverImageId,
                className: "hover-icon w3a--object-contain w3a--rounded"
            }) : null
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/AdapterLoader.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>DetailedLoader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/adapter/IAdapter.js [app-ssr] (ecmascript) <locals>");
;
;
;
;
;
;
;
;
const closeIcon = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
    iconName: "x-light",
    darkIconName: "close"
});
function DetailedLoader(props) {
    const { adapter, appLogo, message, modalStatus, adapterName, onClose } = props;
    const providerIcon = adapter === "twitter" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        imageId: "login-x-dark"
    }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        imageId: `login-${adapter}`,
        height: "30",
        width: "30"
    });
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("adapter loader re-rendering");
        if (modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTED) {
            setTimeout(()=>{
                onClose();
            }, 3000);
        }
    }, [
        modalStatus,
        onClose
    ]);
    return modalStatus !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3ajs-modal-loader w3a-modal__loader w3a--h-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a-modal__loader-content",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: "w3a-modal__loader-info",
                    children: [
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTING && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                    className: "w3a-modal__loader-bridge",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                            className: "w3a-modal__loader-app-logo",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                                                    src: appLogo,
                                                    className: "w3a--block dark:w3a--hidden w3a--h-10 w3a--w-10",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                                                    src: appLogo,
                                                    className: "w3a--hidden dark:w3a--block w3a--h-10 w3a--w-10",
                                                    alt: ""
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                            className: "w3a-modal__connector",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                                className: "w3a-modal__connector-beat",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {}),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {}),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {}),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {}),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {})
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                            className: "w3a-modal__loader-social-logo",
                                            children: providerIcon
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                            className: "w3a-modal__loader-bridge-message",
                                            children: t("modal.adapter-loader.message1", {
                                                adapter: adapterName
                                            })
                                        }),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                            className: "w3a-modal__loader-bridge-message",
                                            children: t("modal.adapter-loader.message2", {
                                                adapter: adapterName
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].CONNECTED && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: "w3a--flex w3a--flex-col w3a--items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    iconName: "connected"
                                }),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                    className: "w3ajs-modal-loader__message w3a-spinner-message w3a--mt-4",
                                    children: message
                                })
                            ]
                        }),
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].ERRORED && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3ajs-modal-loader__message w3a-spinner-message w3a-spinner-message--error",
                            children: message
                        })
                    ]
                })
            }),
            (modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].CONNECTED || modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].ERRORED) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                type: "button",
                className: "w3a-header__button w3ajs-loader-close-btn",
                onClick: onClose,
                children: closeIcon
            })
        ]
    }) : null;
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/styles.css.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>css_248z)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$node_modules$2f$style$2d$inject$2f$dist$2f$style$2d$inject$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/node_modules/style-inject/dist/style-inject.es.js [app-ssr] (ecmascript)");
;
var css_248z = ".w3a-parent-container #w3a-modal button.t-btn,.w3a-parent-container a.t-btn{align-items:center;display:flex;justify-content:center;transition-duration:.15s;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-timing-function:linear}.w3a-parent-container #w3a-modal button.t-btn:not(.t-btn-text):disabled,.w3a-parent-container a.t-btn:not(.t-btn-text):disabled{background-color:var(--app-gray-300);border-width:0;color:var(--app-gray-400)}.w3a-parent-container #w3a-modal button.t-btn:not(.t-btn-text):hover:disabled,.w3a-parent-container a.t-btn:not(.t-btn-text):hover:disabled{background-color:var(--app-gray-300);border-color:var(--app-gray-300);color:var(--app-gray-400)}.w3a-parent-container #w3a-modal button.t-btn:not(.t-btn-text):active:disabled,.w3a-parent-container a.t-btn:not(.t-btn-text):active:disabled{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-offset-width:0px;background-color:var(--app-gray-300);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000);outline-width:0}.w3a-parent-container #w3a-modal button.t-btn:not(.t-btn-text):disabled:is(.w3a--dark *),.w3a-parent-container a.t-btn:not(.t-btn-text):disabled:is(.w3a--dark *){background-color:var(--app-gray-700);color:var(--app-gray-600)}.w3a-parent-container #w3a-modal .size-xs{font-size:.75rem;height:32px;line-height:1rem;padding:.5rem .75rem}.w3a-parent-container #w3a-modal .size-sm{font-size:.875rem;height:36px;line-height:1.25rem;padding:.5rem .75rem}.w3a-parent-container #w3a-modal .size-md{font-size:.875rem;height:42px;line-height:1.25rem;padding:.625rem 1.25rem}.w3a-parent-container #w3a-modal .size-lg{font-size:1rem;height:48px;line-height:1.5rem;padding:.75rem 1.25rem}.w3a-parent-container #w3a-modal .size-xl{font-size:1rem;height:52px;line-height:1.5rem;padding:.875rem 1rem}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary{background-color:var(--app-primary-600);color:var(--app-on-primary);outline:2px solid #0000;outline-offset:2px}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:hover{background-color:var(--app-primary-700)}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:focus-visible{outline-color:var(--app-primary-600);outline-offset:1px;outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:active{background-color:var(--app-primary-600);outline-color:var(--app-primary-600);outline-offset:1px;outline-style:solid;outline-width:1px}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:is(.w3a--dark *){background-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:hover:is(.w3a--dark *){background-color:var(--app-primary-400)}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:focus-visible:is(.w3a--dark *){outline-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-primary:active:is(.w3a--dark *){background-color:var(--app-primary-500);outline-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary{background-color:initial;border-color:var(--app-gray-500);border-width:1px;color:var(--app-gray-600);outline:2px solid #0000;outline-offset:2px}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:hover{background-color:var(--app-gray-200)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);background-color:initial;border-color:var(--app-primary-600);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:active{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);background-color:initial;border-color:var(--app-primary-600);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:is(.w3a--dark *){border-color:var(--app-gray-300);color:var(--app-white)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:hover:is(.w3a--dark *){background-color:var(--app-gray-700)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:focus-visible:is(.w3a--dark *){--tw-ring-color:var(--app-primary-500);background-color:initial;border-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-secondary:active:is(.w3a--dark *){--tw-ring-color:var(--app-primary-500);background-color:initial;border-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary{background-color:var(--app-gray-200);color:var(--app-gray-800)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:hover{background-color:var(--app-gray-300)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:active{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);background-color:var(--app-gray-200);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:is(.w3a--dark *){background-color:var(--app-gray-500);color:var(--app-white)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:hover:is(.w3a--dark *){background-color:var(--app-gray-400)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:focus-visible:is(.w3a--dark *){--tw-ring-color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-tertiary:active:is(.w3a--dark *){--tw-ring-color:var(--app-primary-500);background-color:var(--app-gray-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text{color:var(--app-primary-600)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:hover{color:var(--app-primary-800);text-decoration-line:underline}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:active{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);--tw-ring-color:var(--app-primary-600);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000);color:var(--app-primary-600)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:disabled{color:var(--app-gray-400);text-decoration-line:none}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:is(.w3a--dark *){color:var(--app-primary-500)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:hover:is(.w3a--dark *){color:var(--app-primary-400)}.w3a-parent-container #w3a-modal .t-btn.t-btn-text:disabled:is(.w3a--dark *){color:var(--app-gray-600)}.w3a-parent-container #w3a-modal .btn-link{text-decoration-line:none}.w3a-parent-container #w3a-modal button.t-btn:hover>.hover-icon{display:block;transition:display .15s;transition-timing-function:cubic-bezier(0,.54,.63,.99)}.w3a-parent-container #w3a-modal button.t-btn:hover>.image-icon{display:none;transition:display .15s;transition-timing-function:cubic-bezier(0,.54,.63,.99)}";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$node_modules$2f$style$2d$inject$2f$dist$2f$style$2d$inject$2e$es$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(css_248z);
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Button$1)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$styles$2e$css$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/styles.css.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
;
function Button(props) {
    const { variant = "primary", onClick, children, title, className, style, size = "md", disabled, type = "button" } = props;
    const sizeClass = `size-${size}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
        disabled: disabled,
        type: type,
        className: `t-btn t-btn-${variant} w3a--rounded-full ${sizeClass} ${className}`,
        onClick: onClick,
        title: title,
        style: style,
        children: children
    });
}
var Button$1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["memo"])(Button);
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletButton.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWalletButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
function ExternalWalletButton(props) {
    const { button, handleWalletClick } = props;
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        variant: "tertiary",
        type: "button",
        onClick: ()=>handleWalletClick(button),
        className: "w3a--w-full w3a--rounded-xl w3a--size-xl !w3a--justify-between w3a--items-center wallet-btn",
        title: button.name,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: "w3a--flex w3a--items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        imageId: `login-${button.name}`,
                        hoverImageId: `login-${button.name}`,
                        fallbackImageId: "wallet",
                        height: "24",
                        width: "24",
                        isButton: true,
                        extension: button.imgExtension
                    }),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("p", {
                        className: "w3a--ml-2 w3a--text-left w3a--text-sm",
                        children: button.displayName
                    })
                ]
            }),
            button.hasInjectedWallet && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: "w3a--inline-flex w3a--items-center w3a--rounded-lg w3a--px-2 w3a--py-1 w3a--text-xs w3a--font-medium w3a--bg-app-primary-100 w3a--text-app-primary-800",
                children: t("modal.external.installed")
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Loader.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Loader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/adapter/IAdapter.js [app-ssr] (ecmascript) <locals>");
;
;
;
;
;
const closeIcon = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
    iconName: "close"
});
function Loader(props) {
    const { message, modalStatus, label, onClose, canEmit = true } = props;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("loader re-rendering");
        if (modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTED && canEmit) {
            setTimeout(()=>{
                onClose();
            }, 3000);
        }
    }, [
        canEmit,
        modalStatus,
        onClose
    ]);
    return modalStatus !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3ajs-modal-loader w3a-modal__loader",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a-modal__loader-content",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: "w3a-modal__loader-info",
                    children: [
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTING && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3ajs-modal-loader__spinner w3a-spinner",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                className: "w3a-spinner__spinner"
                            })
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3ajs-modal-loader__label w3a-spinner-label",
                            children: label
                        }),
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].CONNECTED && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3ajs-modal-loader__message w3a-spinner-message",
                            children: message
                        }),
                        modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].ERRORED && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3ajs-modal-loader__message w3a-spinner-message w3a-spinner-message--error",
                            children: message
                        })
                    ]
                })
            }),
            (modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].CONNECTED || modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_STATUS"].ERRORED) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                type: "button",
                className: "w3a-header__button w3ajs-loader-close-btn",
                onClick: onClose,
                children: closeIcon
            })
        ]
    }) : null;
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/WalletConnect.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>WalletConnect$1)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/bowser/src/bowser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$copy$2d$to$2d$clipboard$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/copy-to-clipboard/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$qrcode$2d$logo$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-qrcode-logo/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/context/ThemeContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
function WalletConnect(props) {
    var _getComputedStyle;
    const { walletConnectUri, logoImage, primaryColor } = props;
    const { isDark } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemedContext"]);
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const browser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getParser(window.navigator.userAgent);
        return browser.getPlatformType() === "desktop";
    }, []);
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const [isCopied, setIsCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleCopy = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$copy$2d$to$2d$clipboard$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(walletConnectUri);
        setIsCopied(true);
        setTimeout(()=>{
            setIsCopied(false);
        }, 3000);
    };
    const root = document.documentElement;
    const whiteColor = "#FFFFFF";
    const blackColor = "#000000";
    const modalColor = ((_getComputedStyle = getComputedStyle(root)) === null || _getComputedStyle === void 0 || (_getComputedStyle = _getComputedStyle.getPropertyValue("--app-gray-800")) === null || _getComputedStyle === void 0 ? void 0 : _getComputedStyle.trim()) || "#1f2a37";
    const qrColor = primaryColor.toLowerCase() === "#ffffff" ? "#000000" : primaryColor;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "w3ajs-wallet-connect w3a-wallet-connect",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: "w3ajs-wallet-connect__container w3a-wallet-connect__container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: "w3a-wallet-connect__container-desktop",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                        className: "w3ajs-wallet-connect-qr w3a-wallet-connect-qr w3a--rounded-md w3a--mb-2",
                        tabIndex: 0,
                        role: "button",
                        onClick: handleCopy,
                        onKeyDown: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$copy$2d$to$2d$clipboard$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(walletConnectUri),
                        children: [
                            isCopied && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                className: "tooltip",
                                children: [
                                    "Copied",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                        className: "w3a--absolute w3a--border-8 w3a--border-b-0 w3a--border-r-transparent w3a--border-t-app-gray-900 w3a--border-l-transparent w3a--top-[100%] w3a--left-[calc(50%_-_8px)]"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$qrcode$2d$logo$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QRCode"], {
                                size: isDesktop ? 300 : 260,
                                eyeRadius: 5,
                                qrStyle: "dots",
                                removeQrCodeBehindLogo: true,
                                logoImage: logoImage || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_CONNECT_LOGO"],
                                value: walletConnectUri,
                                logoHeight: 32,
                                logoWidth: 32,
                                logoPadding: 10,
                                eyeColor: isDark ? whiteColor : qrColor,
                                bgColor: isDark ? modalColor : whiteColor,
                                fgColor: isDark ? whiteColor : blackColor
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: "text-xs",
                        children: t("modal.external.walletconnect-copy")
                    })
                ]
            })
        })
    });
}
var WalletConnect$1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["memo"])(WalletConnect);
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletHeader.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWalletHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
function ExternalWalletHeader(props) {
    const { title, goBack, closeModal, disableBackButton } = props;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3a--flex w3a--flex-row w3a--justify-center w3a--items-center w3a--gap-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a--flex-grow-1 w3a--flex-shrink-0 w3a--items-center w3a--justify-start w3a--mr-auto",
                children: !disableBackButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                    type: "button",
                    className: "w3a-external-back w3ajs-external-back",
                    onClick: goBack,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        iconName: "arrow-left-light",
                        darkIconName: "arrow-left-dark",
                        width: "16",
                        height: "16"
                    })
                })
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a-header__title w3a--flex-grow-0 w3a--flex-shrink w3a--truncate w3a--mr-6",
                children: title
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a--flex-grow-1 w3a--flex-shrink-0 w3a--items-center w3a--justify-end w3a--ml-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                    type: "button",
                    onClick: closeModal,
                    className: "w3a-header__button_wallet w3ajs-close-btn",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        iconName: "x-light",
                        darkIconName: "x-dark"
                    })
                })
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletInstall.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWalletInstall)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/bowser/src/bowser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletHeader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const getBrowserExtensionUrl = (browserType, walletId)=>{
    if (walletId !== null && walletId !== void 0 && walletId.startsWith("https://")) return walletId;
    switch(browserType){
        case "chrome":
            return `https://chrome.google.com/webstore/detail/${walletId}`;
        case "firefox":
            return `https://addons.mozilla.org/firefox/addon/${walletId}`;
        case "edge":
            return `https://microsoftedge.microsoft.com/addons/detail/${walletId}`;
        default:
            return null;
    }
};
const getMobileInstallLink = (os, appId)=>{
    if (appId !== null && appId !== void 0 && appId.includes("https://")) {
        return appId;
    }
    switch(os){
        case "android":
            return `https://play.google.com/store/apps/details?id=${appId}`;
        case "ios":
            return `https://apps.apple.com/app/safepal-wallet/${appId}`;
        default:
            return "";
    }
};
const getOsName = (os)=>{
    switch(os){
        case "ios":
            return "iOS";
        case "android":
            return "Android";
        default:
            return "";
    }
};
const getBrowserName = (browser)=>{
    return browser.charAt(0).toUpperCase() + browser.slice(1);
};
function ExternalWalletInstall(props) {
    const { connectButton, goBack, closeModal } = props;
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const deviceDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const browser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getParser(window.navigator.userAgent);
        return {
            platform: browser.getPlatformType(),
            browser: browser.getBrowserName().toLowerCase(),
            os: browser.getOSName()
        };
    }, []);
    const mobileInstallLinks = ()=>{
        const installConfig = connectButton.walletRegistryItem.app || {};
        const installLinks = Object.keys(installConfig).reduce((acc, os)=>{
            if (![
                "android",
                "ios"
            ].includes(os)) return acc;
            const appId = installConfig[os];
            if (!appId) return acc;
            const appUrl = getMobileInstallLink(os, appId);
            if (!appUrl) return acc;
            const logoLight = `${os}-light`;
            const logoDark = `${os}-dark`;
            acc.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("li", {
                className: "w3a--w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("a", {
                    href: appUrl,
                    rel: "noopener noreferrer",
                    target: "_blank",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        type: "button",
                        variant: "tertiary",
                        className: "w3a--w-full !w3a--justify-start w3a--flex w3a--items-center w3a--gap-2 wallet-link-btn",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                imageId: logoLight,
                                darkImageId: logoDark,
                                hoverImageId: logoLight,
                                darkHoverImageId: logoDark,
                                height: "28",
                                width: "28",
                                isButton: true
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                className: "w3a--text-sm w3a--font-medium",
                                children: t("modal.external.install-mobile-app", {
                                    os: getOsName(os)
                                })
                            })
                        ]
                    })
                })
            }, os));
            return acc;
        }, []);
        return installLinks;
    };
    const desktopInstallLinks = ()=>{
        // if browser is brave, use chrome extension
        const browserType = deviceDetails.browser === "brave" ? "chrome" : deviceDetails.browser;
        const browserExtensionConfig = connectButton.walletRegistryItem.app || {};
        const extensionForCurrentBrowser = browserExtensionConfig.browser && browserExtensionConfig.browser.includes(browserType) ? browserExtensionConfig.browser : undefined;
        const browserExtensionId = browserExtensionConfig[browserType] || extensionForCurrentBrowser;
        const browserExtensionUrl = browserExtensionId ? getBrowserExtensionUrl(browserType, browserExtensionId) : null;
        const installLink = browserExtensionUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("li", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("a", {
                href: browserExtensionUrl,
                rel: "noopener noreferrer",
                target: "_blank",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    type: "button",
                    variant: "tertiary",
                    className: "w3a--w-full !w3a--justify-start w3a--flex w3a--items-center w3a--gap-2 wallet-link-btn",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            imageId: deviceDetails.browser,
                            darkImageId: deviceDetails.browser,
                            hoverImageId: deviceDetails.browser,
                            darkHoverImageId: deviceDetails.browser,
                            height: "30",
                            width: "30",
                            isButton: true
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("span", {
                            className: "w3a--text-sm w3a--font-medium",
                            children: t("modal.external.install-browser-extension", {
                                browser: getBrowserName(deviceDetails.browser)
                            })
                        })
                    ]
                })
            })
        }, deviceDetails.browser) : null;
        return [
            installLink,
            ...mobileInstallLinks()
        ];
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                title: `${t("modal.external.get")} ${connectButton.displayName}`,
                goBack: goBack,
                closeModal: closeModal
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a--flex w3a--justify-center w3a--my-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    imageId: `login-${connectButton.name}`,
                    hoverImageId: `login-${connectButton.name}`,
                    fallbackImageId: "wallet",
                    height: "100",
                    width: "100",
                    isButton: true,
                    extension: connectButton.imgExtension
                })
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("ul", {
                className: "w3a--flex w3a--flex-col w3a--gap-3",
                children: deviceDetails.platform === "desktop" ? desktopInstallLinks() : mobileInstallLinks()
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletConnect.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWalletConnect)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Loader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$WalletConnect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/WalletConnect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletHeader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletInstall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletInstall.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function ExternalWalletConnect(props) {
    const { connectButton, walletConnectUri, goBack, closeModal } = props;
    const [isWalletDownloadShown, setIsWalletDownloadShown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const showWalletDownload = ()=>{
        setIsWalletDownloadShown(true);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        children: isWalletDownloadShown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletInstall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                connectButton: connectButton,
                goBack: ()=>setIsWalletDownloadShown(false),
                closeModal: closeModal
            })
        }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    title: connectButton.displayName,
                    goBack: goBack,
                    closeModal: closeModal
                }),
                !walletConnectUri ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    modalStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTING,
                    canEmit: false
                }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$WalletConnect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    walletConnectUri: walletConnectUri,
                    logoImage: `https://images.web3auth.io/login-${connectButton.name}.${connectButton.imgExtension}`,
                    primaryColor: connectButton.walletRegistryItem.primaryColor
                }),
                connectButton.hasInstallLinks && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: "w3a--flex w3a--flex-row w3a--items-center w3a--justify-between w3a--gap-2 w3a--bg-app-gray-50 dark:w3a--bg-app-gray-700 w3a--text-app-gray-900 dark:w3a--text-app-white w3a--px-3 w3a--py-2 w3a--rounded-xl",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                            className: "w3a--text-sm w3a--truncate w3a--flex-grow-0",
                            children: [
                                t("modal.external.dont-have"),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                    children: connectButton.displayName
                                }),
                                "?"
                            ]
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            type: "button",
                            variant: "secondary",
                            size: "xs",
                            className: "w3a--flex-grow-1 w3a--flex-shrink-0",
                            onClick: showWalletDownload,
                            children: t("modal.external.get-wallet")
                        })
                    ]
                })
            ]
        })
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletDetails.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWalletDetail)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletConnect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletConnect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletInstall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletInstall.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
;
function ExternalWalletDetail(props) {
    const { connectButton, walletConnectUri, goBack, closeModal } = props;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        children: connectButton.hasWalletConnect ? /*#__PURE__*/ // Wallet Connect
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletConnect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            connectButton: connectButton,
            walletConnectUri: walletConnectUri,
            goBack: goBack,
            closeModal: closeModal
        }) : /*#__PURE__*/ // Download wallets
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletInstall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            connectButton: connectButton,
            goBack: goBack,
            closeModal: closeModal
        })
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallets.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ExternalWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/bowser/src/bowser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletButton$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletButton.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletDetails$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletDetails.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallet/ExternalWalletHeader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Loader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/wallet/index.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
function formatIOSMobile(params) {
    const encodedUri = encodeURIComponent(params.uri);
    if (params.link.startsWith("http")) return `${params.link}/wc?uri=${encodedUri}`;
    if (params.link) return `${params.link}wc?uri=${encodedUri}`;
    return "";
}
function ExternalWallet(props) {
    const { hideExternalWallets, handleExternalWalletClick, closeModal, config = {}, walletConnectUri, showBackButton, modalStatus, chainNamespace, walletRegistry } = props;
    const [externalButtons, setExternalButtons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [totalExternalWallets, setTotalExternalWallets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedButton, setSelectedButton] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [walletSearch, setWalletSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const walletDiscoverySupported = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const supported = walletRegistry && Object.keys(walletRegistry.default).length > 0 && Object.keys(walletRegistry.others).length > 0;
        return supported;
    }, [
        walletRegistry
    ]);
    const deviceDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const browser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getParser(window.navigator.userAgent);
        return {
            platform: browser.getPlatformType(),
            os: browser.getOSName(),
            browser: browser.getBrowserName().toLowerCase()
        };
    }, []);
    const handleWalletSearch = (e)=>{
        setWalletSearch(e.target.value);
    };
    const adapterVisibilityMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const canShowMap = {};
        Object.keys(config).forEach((adapter)=>{
            const adapterConfig = config[adapter];
            if (!adapterConfig.showOnModal) {
                canShowMap[adapter] = false;
                return;
            }
            if (deviceDetails.platform === "desktop" && adapterConfig.showOnDesktop) {
                canShowMap[adapter] = true;
                return;
            }
            if ((deviceDetails.platform === "mobile" || deviceDetails.platform === "tablet") && adapterConfig.showOnMobile) {
                canShowMap[adapter] = true;
                return;
            }
            canShowMap[adapter] = false;
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("adapter visibility map", canShowMap);
        return canShowMap;
    }, [
        config,
        deviceDetails.platform
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var _config$WALLET_ADAPTE;
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("loaded external wallets", config, walletConnectUri);
        const wcAvailable = (((_config$WALLET_ADAPTE = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2]) === null || _config$WALLET_ADAPTE === void 0 ? void 0 : _config$WALLET_ADAPTE.showOnModal) || false) !== false;
        if (wcAvailable && !walletConnectUri) {
            handleExternalWalletClick({
                adapter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2
            });
        }
    }, [
        config,
        handleExternalWalletClick,
        walletConnectUri
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (walletDiscoverySupported) {
            const isWalletConnectAdapterIncluded = Object.keys(config).some((adapter)=>adapter === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2);
            const defaultButtonKeys = new Set(Object.keys(walletRegistry.default));
            const generateWalletButtons = (wallets)=>{
                return Object.keys(wallets).reduce((acc, wallet)=>{
                    var _config$wallet, _walletRegistryItem$w, _walletRegistryItem$c, _walletRegistryItem$i;
                    if (adapterVisibilityMap[wallet] === false) return acc;
                    const walletRegistryItem = wallets[wallet];
                    let href = "";
                    if (deviceDetails.platform === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$src$2f$bowser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].PLATFORMS_MAP.mobile) {
                        var _walletRegistryItem$m, _walletRegistryItem$m2;
                        const universalLink = walletRegistryItem === null || walletRegistryItem === void 0 || (_walletRegistryItem$m = walletRegistryItem.mobile) === null || _walletRegistryItem$m === void 0 ? void 0 : _walletRegistryItem$m.universal;
                        const deepLink = walletRegistryItem === null || walletRegistryItem === void 0 || (_walletRegistryItem$m2 = walletRegistryItem.mobile) === null || _walletRegistryItem$m2 === void 0 ? void 0 : _walletRegistryItem$m2.native;
                        href = universalLink || deepLink;
                    }
                    const button = {
                        name: wallet,
                        displayName: walletRegistryItem.name,
                        href,
                        hasInjectedWallet: ((_config$wallet = config[wallet]) === null || _config$wallet === void 0 ? void 0 : _config$wallet.isInjected) || false,
                        hasWalletConnect: isWalletConnectAdapterIncluded && ((_walletRegistryItem$w = walletRegistryItem.walletConnect) === null || _walletRegistryItem$w === void 0 || (_walletRegistryItem$w = _walletRegistryItem$w.sdks) === null || _walletRegistryItem$w === void 0 ? void 0 : _walletRegistryItem$w.includes("sign_v2")),
                        hasInstallLinks: Object.keys(walletRegistryItem.app || {}).length > 0,
                        walletRegistryItem,
                        imgExtension: walletRegistryItem.imgExtension || "svg"
                    };
                    // const isBrowserExtensionAvailable = walletRegistryItem.app?.chrome || walletRegistryItem.app?.firefox || walletRegistryItem.app?.edge;
                    if (!button.hasInjectedWallet && !button.hasWalletConnect && !button.hasInstallLinks) return acc;
                    const chainNamespaces = new Set((_walletRegistryItem$c = walletRegistryItem.chains) === null || _walletRegistryItem$c === void 0 ? void 0 : _walletRegistryItem$c.map((chain)=>chain.split(":")[0]));
                    const injectedChainNamespaces = new Set((_walletRegistryItem$i = walletRegistryItem.injected) === null || _walletRegistryItem$i === void 0 ? void 0 : _walletRegistryItem$i.map((injected)=>injected.namespace));
                    if (!chainNamespaces.has(chainNamespace) && !injectedChainNamespaces.has(chainNamespace)) return acc;
                    acc.push(button);
                    return acc;
                }, []);
            };
            // Generate buttons for default and other wallets
            const defaultButtons = generateWalletButtons(walletRegistry.default);
            const otherButtons = generateWalletButtons(walletRegistry.others);
            // Generate custom adapter buttons
            const customAdapterButtons = Object.keys(config).reduce((acc, adapter)=>{
                if (![
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2
                ].includes(adapter) && !config[adapter].isInjected && adapterVisibilityMap[adapter]) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("custom adapter", adapter, config[adapter]);
                    acc.push({
                        name: adapter,
                        displayName: config[adapter].label || adapter,
                        hasInjectedWallet: false,
                        hasWalletConnect: false,
                        hasInstallLinks: false
                    });
                }
                return acc;
            }, []);
            const allButtons = [
                ...defaultButtons,
                ...otherButtons
            ];
            // Filter and set external buttons based on search input
            if (walletSearch) {
                const filteredList = allButtons.concat(customAdapterButtons).filter((button)=>button.name.toLowerCase().includes(walletSearch.toLowerCase()));
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("filteredLists", filteredList);
                setExternalButtons(filteredList);
            } else {
                const sortedButtons = [
                    ...allButtons.filter((button)=>button.hasInjectedWallet && defaultButtonKeys.has(button.name)),
                    ...customAdapterButtons,
                    ...allButtons.filter((button)=>!button.hasInjectedWallet && defaultButtonKeys.has(button.name))
                ];
                setExternalButtons(sortedButtons);
            }
            setTotalExternalWallets(allButtons.length + customAdapterButtons.length);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("external buttons", allButtons);
        } else {
            const buttons = Object.keys(config).reduce((acc, adapter)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("external buttons", adapter, adapterVisibilityMap[adapter]);
                if (![
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2
                ].includes(adapter) && adapterVisibilityMap[adapter]) {
                    acc.push({
                        name: adapter,
                        displayName: config[adapter].label || adapter,
                        hasInjectedWallet: config[adapter].isInjected,
                        hasWalletConnect: false,
                        hasInstallLinks: false
                    });
                }
                return acc;
            }, []);
            setExternalButtons(buttons);
            setTotalExternalWallets(buttons.length);
        }
    }, [
        config,
        deviceDetails,
        adapterVisibilityMap,
        walletRegistry,
        walletSearch,
        chainNamespace,
        walletDiscoverySupported
    ]);
    const handleWalletClick = (button)=>{
        // if has injected wallet, connect to injected wallet
        // if doesn't have wallet connect & doesn't have install links, must be a custom adapter
        if (button.hasInjectedWallet || !button.hasWalletConnect && !button.hasInstallLinks) {
            handleExternalWalletClick({
                adapter: button.name
            });
        } else {
            // else, show wallet detail
            setSelectedButton(button);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: `w3ajs-external-wallet w3a-group ${totalExternalWallets === 0 ? "w3a-group-loader-height" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: "w3a-external-container w3ajs-external-container",
            children: totalExternalWallets === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                modalStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTING,
                canEmit: false
            }) : modalStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED && (// All wallets
            !selectedButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        disableBackButton: !showBackButton,
                        title: t("modal.external.connect-wallet"),
                        goBack: hideExternalWallets,
                        closeModal: closeModal
                    }),
                    totalExternalWallets > 15 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: "w3a--py-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("input", {
                            className: "w3a--w-full w3a-text-field",
                            name: "passwordless-input",
                            required: true,
                            value: walletSearch,
                            placeholder: t("modal.external.search-wallet", {
                                count: totalExternalWallets
                            }),
                            onFocus: (e)=>{
                                e.target.placeholder = "";
                            },
                            onBlur: (e)=>{
                                e.target.placeholder = t("modal.external.search-wallet", {
                                    count: totalExternalWallets
                                });
                            },
                            onChange: (e)=>handleWalletSearch(e)
                        })
                    }),
                    externalButtons.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: "w3a--w-full w3a--text-center w3a--text-app-gray-400 dark:w3a--text-app-gray-500 w3a--py-6 w3a--flex w3a--justify-center w3a--items-center",
                        children: t("modal.external.no-wallets-found")
                    }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: `w3a-adapter-list-container ${totalExternalWallets < 15 ? "w3a--py-4" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("ul", {
                            className: "w3a-adapter-list w3ajs-wallet-adapters",
                            children: [
                                externalButtons.map((button)=>{
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("li", {
                                        className: "w3a-adapter-item w3a-adapter-item--full",
                                        children: [
                                            deviceDetails.platform === "desktop" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletButton$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                button: button,
                                                handleWalletClick: handleWalletClick
                                            }),
                                            deviceDetails.platform !== "desktop" && (button.href && button.hasWalletConnect && !button.hasInjectedWallet ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("a", {
                                                href: button.href ? formatIOSMobile({
                                                    uri: walletConnectUri,
                                                    link: button.href
                                                }) : walletConnectUri,
                                                target: "_blank",
                                                className: "w3a--w-full",
                                                rel: "noreferrer noopener",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletButton$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    button: button,
                                                    handleWalletClick: handleWalletClick
                                                })
                                            }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletButton$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                button: button,
                                                handleWalletClick: handleWalletClick
                                            }))
                                        ]
                                    }, button.name + button.displayName);
                                }),
                                totalExternalWallets > 10 && !walletSearch && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("li", {
                                    className: "w3a--flex w3a--flex-col w3a--items-center w3a--justify-center w3a--gap-y-0.5 w3a--my-4 w3a--w-full w3a--mx-auto w3a-adapter-item--full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("p", {
                                            className: "w3a--text-xs w3a--text-app-gray-500 dark:w3a--text-app-gray-400",
                                            children: t("modal.external.search-text")
                                        }),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("p", {
                                            className: "w3a--text-xs w3a--font-medium w3a--text-app-gray-900 dark:w3a--text-app-white",
                                            children: t("modal.external.search-subtext")
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }) : /*#__PURE__*/ // Wallet Detail
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallet$2f$ExternalWalletDetails$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                connectButton: selectedButton,
                goBack: ()=>setSelectedButton(null),
                walletConnectUri: walletConnectUri,
                closeModal: closeModal
            }))
        })
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SelfCustodyViaWeb3Auth.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>SelfCustodyViaWeb3Auth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
function SelfCustodyViaWeb3Auth() {
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3a--flex w3a--items-center w3a--gap-2 w3a--justify-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a--text-xs w3a--text-app-gray-300 dark:w3a--text-app-gray-500",
                children: t("modal.footer.message-new")
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                height: "16",
                src: "https://images.web3auth.io/web3auth-footer-logo-light.svg",
                alt: "Web3Auth Logo Light",
                className: "w3a--h-4 w3a--block dark:w3a--hidden"
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                height: "16",
                src: "https://images.web3auth.io/web3auth-footer-logo-dark.svg",
                alt: "Web3Auth Logo Dark",
                className: "w3a--h-4 w3a--hidden dark:w3a--block"
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Footer.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Footer)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SelfCustodyViaWeb3Auth$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SelfCustodyViaWeb3Auth.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
;
;
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "w3a-modal__footer",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: "w3a-footer",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SelfCustodyViaWeb3Auth$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {})
                })
            })
        })
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Header.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>memoizedHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
function Header(props) {
    const { onClose, appLogo, appName } = props;
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const headerLogo = [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_LOGO_DARK"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_LOGO_LIGHT"]
    ].includes(appLogo) ? "" : appLogo;
    const subtitle = t("modal.header-subtitle-name", {
        appName
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3a-modal__header",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a-header",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    children: [
                        headerLogo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3a-header__logo",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("img", {
                                src: headerLogo,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3a-header__title",
                            children: t("modal.header-title")
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: "w3a-header__subtitle",
                            children: [
                                subtitle,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                    className: "w3a--relative w3a--flex w3a--flex-col w3a--items-center w3a--group w3a--cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            iconName: "information-circle-light",
                                            darkIconName: "information-circle"
                                        }),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                            className: "w3a--absolute w3a--top-4 w3a--z-20 w3a--flex-col w3a--items-center w3a--hidden w3a--mb-5 group-hover:w3a--flex",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                                    className: "w3a--w-3 w3a--h-3 w3a--ml-[3px] -w3a--mb-2 w3a--rotate-45 w3a--bg-app-gray-50 dark:w3a--bg-app-gray-600"
                                                }),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                                    className: `w3a--relative w3a--p-4 w3a--w-[270px] w3a--translate-x-[-16px] w3a--text-xs w3a--leading-none w3a--text-app-white w3a--rounded-md w3a--bg-app-gray-50 dark:w3a--bg-app-gray-600 w3a--shadow-lg ${subtitle.length > 34 ? "-w3a--ml-[100px]" : ""}`,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                                            className: "w3a--text-xs w3a--font-medium w3a--mb-1 w3a--text-app-gray-900 dark:w3a--text-app-white",
                                                            children: t("modal.header-tooltip-title")
                                                        }),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                                            className: "w3a--text-xs w3a--text-app-gray-400",
                                                            children: t("modal.header-tooltip-desc")
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                type: "button",
                onClick: onClose,
                className: "w3a-header__button w3ajs-close-btn ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    iconName: "x-light",
                    darkIconName: "x-dark"
                })
            })
        ]
    });
}
const memoizedHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["memo"])(Header, (prevProps, nextProps)=>{
    if (prevProps.appLogo !== nextProps.appLogo) {
        return true;
    }
    return false;
});
memoizedHeader.displayName = "Header";
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/utils.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "getAdapterSocialLogins": (()=>getAdapterSocialLogins),
    "getNetworkIconId": (()=>getNetworkIconId),
    "getUserCountry": (()=>getUserCountry),
    "getUserLanguage": (()=>getUserLanguage),
    "passwordlessBackendUrl": (()=>passwordlessBackendUrl),
    "validateImageUrl": (()=>validateImageUrl),
    "validatePhoneNumber": (()=>validatePhoneNumber)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@babel/runtime/helpers/objectSpread2.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/config.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$toruslabs$2f$http$2d$helpers$2f$dist$2f$lib$2e$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@toruslabs/http-helpers/dist/lib.esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/wallet/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$errors$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/errors/index.js [app-ssr] (ecmascript)");
;
;
;
;
;
const getAdapterSocialLogins = (adapterName, loginMethodsConfig = {})=>{
    const finalLoginMethodsConfig = {};
    if (adapterName === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].AUTH) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUTH_PROVIDERS"].forEach((loginMethod)=>{
            const currentLoginMethodConfig = loginMethodsConfig[loginMethod] || {
                name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUTH_PROVIDERS_NAMES"][loginMethod],
                showOnMobile: true,
                showOnModal: true,
                showOnDesktop: true
            };
            finalLoginMethodsConfig[loginMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, currentLoginMethodConfig);
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("auth login method ui config", finalLoginMethodsConfig);
    } else {
        throw __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$errors$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WalletInitializationError"].invalidParams(`${adapterName} is not a valid adapter`);
    }
    return finalLoginMethodsConfig;
};
async function validateImageUrl(url) {
    return new Promise((resolve, reject)=>{
        const img = new Image();
        img.src = url;
        if (img.complete) {
            resolve(true);
        } else {
            img.addEventListener("load", ()=>{
                resolve(true);
            });
            img.addEventListener("error", ()=>{
                reject();
            });
        }
    });
}
async function getNetworkIconId(ticker) {
    const fallbackId = "network-default";
    if (!ticker) return fallbackId;
    try {
        const url = `https://images.web3auth.io/network-${ticker.toLowerCase()}.svg`;
        const isValid = await validateImageUrl(url);
        if (isValid) {
            return `network-${ticker.toLowerCase()}`;
        }
        return fallbackId;
    } catch  {
        return fallbackId;
    }
}
const passwordlessBackendUrl = "https://api-passwordless.web3auth.io";
const getUserCountry = async ()=>{
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$toruslabs$2f$http$2d$helpers$2f$dist$2f$lib$2e$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["get"])(`${passwordlessBackendUrl}/api/v3/user/location`);
        if (result && result.data.country) return {
            country: result.data.country,
            dialCode: result.data.dial_code
        };
        return null;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error("error getting user country", error);
        return null;
    }
};
const validatePhoneNumber = async (phoneNumber)=>{
    try {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$toruslabs$2f$http$2d$helpers$2f$dist$2f$lib$2e$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["post"])(`${passwordlessBackendUrl}/api/v3/phone_number/validate`, {
            phone_number: phoneNumber
        });
        if (result && result.success) return result.parsed_number;
        return false;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error("error validating phone number", error);
        if (error.status === 400) {
            return false;
        }
        // sending true because we don't want the user to be stuck on a flow
        // if there is an error with the api or something went wrong.
        return true;
    }
};
const getUserLanguage = (defaultLanguage)=>{
    let userLanguage = defaultLanguage;
    if (!userLanguage) {
        const browserLanguage = typeof window !== "undefined" ? window.navigator.userLanguage || window.navigator.language || "en-US" : "en-US";
        userLanguage = browserLanguage.split("-")[0];
    }
    return Object.prototype.hasOwnProperty.call(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGE_MAP"], userLanguage) ? userLanguage : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].en;
};
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SocialLoginPasswordless.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>SocialLoginPasswordless)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Icon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/constants.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
function SocialLoginPasswordless(props) {
    const { handleSocialLoginClick, adapter, isPrimaryBtn, isEmailVisible, isSmsVisible } = props;
    const [fieldValue, setFieldValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [countryCode, setCountryCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [isValidInput, setIsValidInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const handleFormSubmit = async (e)=>{
        e.preventDefault();
        const value = fieldValue;
        if (isEmailVisible) {
            const isEmailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
            if (isEmailValid) {
                return handleSocialLoginClick({
                    adapter,
                    loginParams: {
                        loginProvider: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].EMAIL_PASSWORDLESS,
                        login_hint: value,
                        name: "Email"
                    }
                });
            }
        }
        if (isSmsVisible) {
            const number = value.startsWith("+") ? value : `${countryCode}${value}`;
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validatePhoneNumber"])(number);
            if (result) {
                return handleSocialLoginClick({
                    adapter,
                    loginParams: {
                        loginProvider: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].SMS_PASSWORDLESS,
                        login_hint: typeof result === "string" ? result : number,
                        name: "Mobile"
                    }
                });
            }
        }
        setIsValidInput(false);
        return undefined;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const getLocation = async ()=>{
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUserCountry"])();
            if (result && result.dialCode) {
                setCountryCode(result.dialCode);
            }
        };
        if (isSmsVisible) getLocation();
    }, [
        isSmsVisible
    ]);
    const handleInputChange = (e)=>{
        setFieldValue(e.target.value);
        if (isValidInput === false) setIsValidInput(null);
    };
    const title = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (isEmailVisible && isSmsVisible) return "modal.social.passwordless-title";
        if (isEmailVisible) return "modal.social.email";
        return "modal.social.phone";
    }, [
        isEmailVisible,
        isSmsVisible
    ]);
    const placeholder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (isEmailVisible && isSmsVisible) return "+(00)123456/name@example.com";
        if (isEmailVisible) return "name@example.com";
        return "+(00)123456";
    }, [
        isEmailVisible,
        isSmsVisible
    ]);
    const invalidInputErrorMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (isEmailVisible && isSmsVisible) return "modal.errors-invalid-number-email";
        if (isEmailVisible) return "modal.errors-invalid-email";
        return "modal.errors-invalid-number";
    }, [
        isEmailVisible,
        isSmsVisible
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3ajs-passwordless w3a-group w3a-group--passwordless",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: "w3a-group__title",
                children: [
                    t(title),
                    isSmsVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                        className: "w3a--relative w3a--flex w3a--flex-col w3a--items-center w3a--cursor-pointer w3a--group",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                iconName: "information-circle-light",
                                darkIconName: "information-circle"
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                className: "w3a--absolute w3a--z-20 w3a--flex-col w3a--items-center w3a--hidden w3a--mb-5 w3a--top-4 group-hover:w3a--flex",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                        className: "w3a--w-3 w3a--h-3 w3a--ml-[3px] -w3a--mb-2 w3a--rotate-45 w3a--bg-app-gray-50 dark:w3a--bg-app-gray-600"
                                    }),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                        className: `w3a--relative w3a--p-4 w3a--w-[300px] w3a--text-xs w3a--leading-none w3a--text-app-white w3a--rounded-md w3a--bg-app-gray-50 dark:w3a--bg-app-gray-600 w3a--shadow-lg ${isSmsVisible && !isEmailVisible ? "w3a--left-20" : "w3a--left-8"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                                className: "w3a--mb-1 w3a--text-xs w3a--font-medium w3a--text-app-gray-900 dark:w3a--text-app-white",
                                                children: t("modal.popup.phone-header")
                                            }),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                                className: "w3a--text-xs w3a--text-app-gray-400",
                                                children: t("modal.popup.phone-body")
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("form", {
                className: "w3ajs-passwordless-form",
                onSubmit: (e)=>handleFormSubmit(e),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("input", {
                        className: "w3a--w-full w3a--mb-4 w3a-text-field",
                        name: "passwordless-input",
                        required: true,
                        placeholder: `${t("modal.social.sms-placeholder-text")} ${placeholder}`,
                        onFocus: (e)=>{
                            e.target.placeholder = "";
                        },
                        onBlur: (e)=>{
                            e.target.placeholder = `${t("modal.social.sms-placeholder-text")} ${placeholder}`;
                        },
                        onChange: (e)=>handleInputChange(e)
                    }),
                    isValidInput === false && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: "w3a-sms-field--error",
                        children: t(invalidInputErrorMessage)
                    }),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        variant: isPrimaryBtn ? "primary" : "tertiary",
                        disabled: fieldValue === "",
                        className: "w3a--w-full",
                        type: "submit",
                        children: t("modal.social.passwordless-cta")
                    })
                ]
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SocialLogins.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>SocialLogins)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/classnames/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/config.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/context/ThemeContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function getProviderIcon(method, isDark, isPrimaryBtn) {
    const imageId = method === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].TWITTER ? `login-twitter-x${isDark ? "-light" : "-dark"}` : `login-${method}${isDark ? "-light" : "-dark"}`;
    const hoverId = method === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].APPLE || method === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].GITHUB || method === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].TWITTER ? imageId : `login-${method}-active`;
    if (isPrimaryBtn) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            width: "20",
            imageId: hoverId,
            hoverImageId: hoverId,
            isButton: true
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        width: "20",
        imageId: imageId,
        hoverImageId: hoverId,
        isButton: true
    });
}
function SocialLogins(props) {
    const [canShowMore, setCanShowMore] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { socialLoginsConfig = {
        loginMethods: {},
        loginMethodsOrder: [],
        adapter: "",
        uiConfig: {}
    }, handleSocialLoginClick } = props;
    const { isDark } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemedContext"]);
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    // Too small a function to use `useCallback`
    const expandClickHandler = ()=>{
        setIsExpanded(!isExpanded);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const maxOptions = Object.keys(socialLoginsConfig.loginMethods).filter((loginMethodKey)=>{
            return socialLoginsConfig.loginMethods[loginMethodKey].showOnModal;
        });
        setCanShowMore(maxOptions.length > 4);
    }, [
        socialLoginsConfig.loginMethods
    ]);
    const adapterListClass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("w3a-adapter-list", "w3ajs-socials-adapters", !isExpanded ? " w3a-adapter-list--shrink" : "");
    const adapterButtonClass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("w3a-button-expand", "w3ajs-button-expand", isExpanded ? "w3a-button--rotate" : "");
    const adapterExpandText = isExpanded ? t("modal.social.view-less") : t("modal.social.view-more");
    const loginMethodsCount = Object.keys(socialLoginsConfig.loginMethods).length + 1;
    const restrictedLoginMethods = [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].WEBAUTHN,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].JWT,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].SMS_PASSWORDLESS,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].EMAIL_PASSWORDLESS,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].AUTHENTICATOR,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].PASSKEYS
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "w3ajs-social-logins w3a-group",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("ul", {
                className: adapterListClass,
                children: Object.keys(socialLoginsConfig.loginMethods).map((method)=>{
                    var _socialLoginsConfig$u, _socialLoginsConfig$u2;
                    const name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["capitalizeFirstLetter"])(socialLoginsConfig.loginMethods[method].name || method);
                    const orderIndex = socialLoginsConfig.loginMethodsOrder.indexOf(method) + 1;
                    const order = orderIndex || Object.keys(socialLoginsConfig.loginMethods).length + 1;
                    const isMainOption = socialLoginsConfig.loginMethods[method].mainOption;
                    const isPrimaryBtn = (socialLoginsConfig === null || socialLoginsConfig === void 0 || (_socialLoginsConfig$u = socialLoginsConfig.uiConfig) === null || _socialLoginsConfig$u === void 0 ? void 0 : _socialLoginsConfig$u.primaryButton) === "socialLogin" && order === 1;
                    const providerIcon = getProviderIcon(method, isDark, isPrimaryBtn);
                    if (socialLoginsConfig.loginMethods[method].showOnModal === false || restrictedLoginMethods.includes(method)) {
                        return null;
                    }
                    const loginMethodSpan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("w3a-adapter-item", (socialLoginsConfig === null || socialLoginsConfig === void 0 || (_socialLoginsConfig$u2 = socialLoginsConfig.uiConfig) === null || _socialLoginsConfig$u2 === void 0 ? void 0 : _socialLoginsConfig$u2.loginGridCol) === 2 ? "w3a--col-span-3" : "w3a--col-span-2");
                    if (isMainOption || order === 1) {
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("li", {
                            className: "w3a--col-span-6 w3a-adapter-item",
                            style: {
                                order
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                variant: "secondary",
                                onClick: ()=>handleSocialLoginClick({
                                        adapter: socialLoginsConfig.adapter,
                                        loginParams: {
                                            loginProvider: method,
                                            name,
                                            login_hint: ""
                                        }
                                    }),
                                className: "w3a--w-full",
                                title: name,
                                children: [
                                    providerIcon,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("p", {
                                        className: "w3a--ml-2",
                                        children: t("modal.social.continueCustom", {
                                            adapter: name
                                        })
                                    })
                                ]
                            })
                        }, method);
                    }
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("li", {
                        className: loginMethodSpan,
                        style: {
                            order: order + loginMethodsCount
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            variant: "secondary",
                            onClick: ()=>handleSocialLoginClick({
                                    adapter: socialLoginsConfig.adapter,
                                    loginParams: {
                                        loginProvider: method,
                                        name,
                                        login_hint: ""
                                    }
                                }),
                            className: "w3a--w-full",
                            title: name,
                            children: providerIcon
                        })
                    }, method);
                })
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a-social__policy",
                children: t("modal.social.policy")
            }),
            canShowMore && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "w3a--text-right",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("button", {
                    type: "button",
                    className: adapterButtonClass,
                    onClick: expandClickHandler,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("span", {
                        className: "w3ajs-button-expand-text",
                        children: adapterExpandText
                    })
                })
            })
        ]
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Modal.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Modal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@babel/runtime/helpers/objectSpread2.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/deepmerge/dist/cjs.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$AdapterLoader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/AdapterLoader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Button/Button.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallets$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/ExternalWallets.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Footer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Footer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Header$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Header.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SocialLoginPasswordless$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SocialLoginPasswordless.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SocialLogins$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/SocialLogins.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-i18next/dist/es/useTranslation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$toruslabs$2f$base$2d$controllers$2f$dist$2f$lib$2e$esm$2f$utils$2f$lodashUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@toruslabs/base-controllers/dist/lib.esm/utils/lodashUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/wallet/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/constants.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].enableAll();
function Modal(props) {
    var _modalState$socialLog, _modalState$socialLog2, _modalState$socialLog5, _modalState$socialLog7, _modalState$socialLog9, _modalState$socialLog10;
    const [modalTransitionClasses, setModalTransitionClasses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        "w3a-modal__inner"
    ]);
    const [modalState, setModalState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        externalWalletsVisibility: false,
        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED,
        hasExternalWallets: false,
        externalWalletsInitialized: false,
        modalVisibility: false,
        modalVisibilityDelayed: false,
        postLoadingMessage: "",
        walletConnectUri: "",
        socialLoginsConfig: {
            loginMethods: {},
            loginMethodsOrder: [],
            adapter: "",
            uiConfig: {}
        },
        externalWalletsConfig: {},
        detailedLoaderAdapter: "",
        detailedLoaderAdapterName: "",
        showExternalWalletsOnly: false
    });
    const [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$useTranslation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])(undefined, {
        i18n: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    });
    const { stateListener, appLogo, appName, chainNamespace, walletRegistry, handleSocialLoginClick, handleExternalWalletClick, handleShowExternalWallets, closeModal } = props;
    const [transition, setTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        stateListener.emit("MOUNTED");
        stateListener.on("STATE_UPDATED", (newModalState)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("state updated", newModalState);
            setModalState((prevState)=>{
                const mergedState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$toruslabs$2f$base$2d$controllers$2f$dist$2f$lib$2e$esm$2f$utils$2f$lodashUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneDeep"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(prevState, newModalState));
                return mergedState;
            });
        });
    }, [
        stateListener
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let timeOutId;
        if (modalState.modalVisibility) {
            setModalState((prevState)=>{
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                    modalVisibilityDelayed: modalState.modalVisibility
                });
            });
            timeOutId = window.setTimeout(()=>{
                setModalTransitionClasses([
                    "w3a-modal__inner",
                    modalState.modalVisibility ? "w3a-modal__inner--active" : ""
                ]);
            // hide external wallets, if modal is closing, so that it will show social login screen on reopen.
            }, 100);
        } else {
            setModalTransitionClasses([
                "w3a-modal__inner",
                modalState.modalVisibility ? "w3a-modal__inner--active" : ""
            ]);
            // hide external wallets, if modal is closing, so that it will show social login screen on reopen.
            timeOutId = window.setTimeout(()=>{
                setModalState((prevState)=>{
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                        modalVisibilityDelayed: modalState.modalVisibility
                    });
                });
            }, 250);
        }
        return ()=>{
            clearTimeout(timeOutId);
        };
    }, [
        modalState.modalVisibility
    ]);
    const onCloseLoader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (modalState.status === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTED) {
            closeModal();
        }
        if (modalState.status === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].ERRORED) {
            setModalState((prevState)=>{
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                    modalVisibility: true,
                    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED
                });
            });
        }
    }, [
        closeModal,
        modalState.status
    ]);
    const preHandleExternalWalletClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((params)=>{
        const { adapter } = params;
        setModalState((prevState)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                detailedLoaderAdapter: adapter,
                detailedLoaderAdapterName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ADAPTER_NAMES"][adapter]
            });
        });
        handleExternalWalletClick(params);
    }, [
        handleExternalWalletClick
    ]);
    const preHandleSocialWalletClick = (params)=>{
        const { loginParams } = params;
        setModalState((prevState)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                detailedLoaderAdapter: loginParams.loginProvider,
                detailedLoaderAdapterName: loginParams.name
            });
        });
        handleSocialLoginClick(params);
    };
    const isEmailPrimary = ((_modalState$socialLog = modalState.socialLoginsConfig) === null || _modalState$socialLog === void 0 || (_modalState$socialLog = _modalState$socialLog.uiConfig) === null || _modalState$socialLog === void 0 ? void 0 : _modalState$socialLog.primaryButton) === "emailLogin";
    const isExternalPrimary = ((_modalState$socialLog2 = modalState.socialLoginsConfig) === null || _modalState$socialLog2 === void 0 || (_modalState$socialLog2 = _modalState$socialLog2.uiConfig) === null || _modalState$socialLog2 === void 0 ? void 0 : _modalState$socialLog2.primaryButton) === "externalLogin";
    const externalWalletButton = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "w3ajs-external-wallet w3a-group w3a--w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: "w3a-external-toggle w3ajs-external-toggle",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                variant: isExternalPrimary ? "primary" : "tertiary",
                type: "button",
                className: "w3a--w-full w3ajs-external-toggle__button",
                style: {
                    width: "100%"
                },
                onClick: ()=>{
                    setModalState((prevState)=>{
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                            externalWalletsVisibility: true
                        });
                    });
                    setTransition("slide-enter");
                    handleShowExternalWallets(modalState.externalWalletsInitialized);
                    setTimeout(()=>{
                        setTransition("slide-exit");
                    }, 300);
                },
                children: t("modal.external.connect")
            })
        })
    });
    const areSocialLoginsVisible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var _modalState$socialLog3, _modalState$socialLog4;
        if (modalState.showExternalWalletsOnly) return false;
        if (Object.keys(((_modalState$socialLog3 = modalState.socialLoginsConfig) === null || _modalState$socialLog3 === void 0 ? void 0 : _modalState$socialLog3.loginMethods) || {}).length === 0) return false;
        const isAnySocialLoginVisible = Object.entries(((_modalState$socialLog4 = modalState.socialLoginsConfig) === null || _modalState$socialLog4 === void 0 ? void 0 : _modalState$socialLog4.loginMethods) || {}).some(([k, v])=>k !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].EMAIL_PASSWORDLESS && v.showOnModal !== false);
        if (isAnySocialLoginVisible) return true;
        return false;
    }, [
        modalState.showExternalWalletsOnly,
        (_modalState$socialLog5 = modalState.socialLoginsConfig) === null || _modalState$socialLog5 === void 0 ? void 0 : _modalState$socialLog5.loginMethods
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("modal state", modalState, areSocialLoginsVisible);
    const isEmailPasswordlessLoginVisible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var _modalState$socialLog6;
        return (_modalState$socialLog6 = modalState.socialLoginsConfig) === null || _modalState$socialLog6 === void 0 || (_modalState$socialLog6 = _modalState$socialLog6.loginMethods[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].EMAIL_PASSWORDLESS]) === null || _modalState$socialLog6 === void 0 ? void 0 : _modalState$socialLog6.showOnModal;
    }, [
        (_modalState$socialLog7 = modalState.socialLoginsConfig) === null || _modalState$socialLog7 === void 0 ? void 0 : _modalState$socialLog7.loginMethods
    ]);
    const isSmsPasswordlessLoginVisible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var _modalState$socialLog8;
        return (_modalState$socialLog8 = modalState.socialLoginsConfig) === null || _modalState$socialLog8 === void 0 || (_modalState$socialLog8 = _modalState$socialLog8.loginMethods[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_PROVIDER"].SMS_PASSWORDLESS]) === null || _modalState$socialLog8 === void 0 ? void 0 : _modalState$socialLog8.showOnModal;
    }, [
        (_modalState$socialLog9 = modalState.socialLoginsConfig) === null || _modalState$socialLog9 === void 0 ? void 0 : _modalState$socialLog9.loginMethods
    ]);
    return modalState.modalVisibilityDelayed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        id: "w3a-modal",
        className: "w3a-modal",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: `${modalTransitionClasses.join(" ")} ${modalState.status !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED ? "w3a--p-6 w3a--pt-7" : ""} ${(areSocialLoginsVisible || isEmailPasswordlessLoginVisible || isSmsPasswordlessLoginVisible) && !modalState.externalWalletsVisibility ? "" : "wallet-adapter-container"}`,
            children: [
                modalState.status !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Header$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            onClose: closeModal,
                            appLogo: appLogo,
                            appName: appName
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: "w3a-modal__content w3ajs-content",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$AdapterLoader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                onClose: onCloseLoader,
                                appLogo: appLogo,
                                modalStatus: modalState.status,
                                message: t(modalState.postLoadingMessage),
                                adapter: modalState.detailedLoaderAdapter,
                                adapterName: modalState.detailedLoaderAdapterName
                            })
                        })
                    ]
                }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: `transition-wrapper ${transition}`,
                    children: (areSocialLoginsVisible || isEmailPasswordlessLoginVisible || isSmsPasswordlessLoginVisible) && !modalState.externalWalletsVisibility ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Header$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                onClose: closeModal,
                                appLogo: appLogo,
                                appName: appName
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                className: "w3a-modal__content w3ajs-content",
                                children: [
                                    areSocialLoginsVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SocialLogins$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        handleSocialLoginClick: (params)=>preHandleSocialWalletClick(params),
                                        socialLoginsConfig: modalState.socialLoginsConfig
                                    }) : null,
                                    (isEmailPasswordlessLoginVisible || isSmsPasswordlessLoginVisible) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$SocialLoginPasswordless$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        isEmailVisible: isEmailPasswordlessLoginVisible,
                                        isSmsVisible: isSmsPasswordlessLoginVisible,
                                        adapter: (_modalState$socialLog10 = modalState.socialLoginsConfig) === null || _modalState$socialLog10 === void 0 ? void 0 : _modalState$socialLog10.adapter,
                                        handleSocialLoginClick: (params)=>preHandleSocialWalletClick(params),
                                        isPrimaryBtn: isEmailPrimary
                                    }),
                                    modalState.hasExternalWallets && externalWalletButton
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: "w3a-modal__content_external_wallet w3ajs-content",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$ExternalWallets$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            modalStatus: modalState.status,
                            showBackButton: areSocialLoginsVisible || isEmailPasswordlessLoginVisible || isSmsPasswordlessLoginVisible,
                            handleExternalWalletClick: preHandleExternalWalletClick,
                            chainNamespace: chainNamespace,
                            walletConnectUri: modalState.walletConnectUri,
                            config: modalState.externalWalletsConfig,
                            hideExternalWallets: ()=>setModalState((prevState)=>{
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$objectSpread2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({}, prevState), {}, {
                                        externalWalletsVisibility: false
                                    });
                                }),
                            walletRegistry: walletRegistry,
                            closeModal: closeModal
                        })
                    })
                }),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Footer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {})
            ]
        })
    });
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/loginModal.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "LoginModal": (()=>LoginModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@babel/runtime/helpers/defineProperty.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$css$2f$web3auth$2e$css$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/css/web3auth.css.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react-dom/client.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Modal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/components/Modal.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/context/ThemeContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/localeImport.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/loglevel.js [app-ssr] (ecmascript) <export default as log>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$whitelabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/utils/whitelabel.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/wallet/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/base/dist/lib.esm/adapter/IAdapter.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$jrpc$2f$safeEventEmitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/auth/dist/lib.esm/jrpc/safeEventEmitter.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
function createWrapper(parentZIndex) {
    const existingWrapper = document.getElementById("w3a-parent-container");
    if (existingWrapper) existingWrapper.remove();
    const parent = document.createElement("section");
    parent.classList.add("w3a-parent-container");
    parent.setAttribute("id", "w3a-parent-container");
    parent.style.zIndex = parentZIndex;
    parent.style.position = "relative";
    const wrapper = document.createElement("section");
    wrapper.setAttribute("id", "w3a-container");
    parent.appendChild(wrapper);
    document.body.appendChild(parent);
    return wrapper;
}
class LoginModal extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$jrpc$2f$safeEventEmitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SafeEventEmitter"] {
    constructor(_uiConfig){
        super();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "uiConfig", void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "stateEmitter", void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "chainNamespace", void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "walletRegistry", void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "initModal", async ()=>{
            const darkState = {
                isDark: this.isDark
            };
            const useLang = this.uiConfig.defaultLanguage || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].en;
            // Load new language resource
            if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].de) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/german.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].ja) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/japanese.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].ko) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/korean.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].zh) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/mandarin.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].es) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/spanish.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].fr) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/french.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].pt) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/portuguese.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].nl) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/dutch.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].tr) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/turkish.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            } else if (useLang === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LANGUAGES"].en) {
                __turbopack_require__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/english.json.js [app-ssr] (ecmascript, async loader)")(__turbopack_import__).then((messages)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].addResourceBundle(useLang, "translation", messages.default);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$localeImport$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].changeLanguage(useLang);
                }).catch((error)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error(error);
                });
            }
            return new Promise((resolve)=>{
                var _this$uiConfig;
                this.stateEmitter.once("MOUNTED", ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("rendered");
                    this.setState({
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED
                    });
                    return resolve();
                });
                const container = createWrapper(this.uiConfig.modalZIndex);
                if (darkState.isDark) {
                    container.classList.add("w3a--dark");
                } else {
                    container.classList.remove("w3a--dark");
                }
                const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createRoot"])(container);
                root.render(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$context$2f$ThemeContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemedContext"].Provider, {
                    value: darkState,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$components$2f$Modal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        closeModal: this.closeModal,
                        stateListener: this.stateEmitter,
                        handleShowExternalWallets: this.handleShowExternalWallets,
                        handleExternalWalletClick: this.handleExternalWalletClick,
                        handleSocialLoginClick: this.handleSocialLoginClick,
                        appLogo: darkState.isDark ? this.uiConfig.logoDark : this.uiConfig.logoLight,
                        appName: this.uiConfig.appName,
                        chainNamespace: this.chainNamespace,
                        walletRegistry: this.walletRegistry
                    })
                }));
                if ((_this$uiConfig = this.uiConfig) !== null && _this$uiConfig !== void 0 && _this$uiConfig.theme) {
                    const rootElement = document.getElementById("w3a-parent-container");
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$utils$2f$whitelabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["applyWhiteLabelTheme"])(rootElement, this.uiConfig.theme);
                }
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "addSocialLogins", (adapter, loginMethods, loginMethodsOrder, uiConfig)=>{
            this.setState({
                socialLoginsConfig: {
                    adapter,
                    loginMethods,
                    loginMethodsOrder,
                    uiConfig
                }
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("addSocialLogins", adapter, loginMethods, loginMethodsOrder, uiConfig);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "addWalletLogins", (externalWalletsConfig, options)=>{
            this.setState({
                externalWalletsConfig,
                externalWalletsInitialized: true,
                showExternalWalletsOnly: !!(options !== null && options !== void 0 && options.showExternalWalletsOnly),
                externalWalletsVisibility: true
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "open", ()=>{
            this.setState({
                modalVisibility: true
            });
            this.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_MODAL_EVENTS"].MODAL_VISIBILITY, true);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "closeModal", ()=>{
            this.setState({
                modalVisibility: false,
                externalWalletsVisibility: false
            });
            this.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_MODAL_EVENTS"].MODAL_VISIBILITY, false);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "initExternalWalletContainer", ()=>{
            this.setState({
                hasExternalWallets: true
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "handleShowExternalWallets", (status)=>{
            this.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_MODAL_EVENTS"].INIT_EXTERNAL_WALLETS, {
                externalWalletsInitialized: status
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "handleExternalWalletClick", (params)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("external wallet clicked", params);
            const { adapter } = params;
            this.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_MODAL_EVENTS"].LOGIN, {
                adapter
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "handleSocialLoginClick", (params)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("social login clicked", params);
            const { adapter, loginParams } = params;
            this.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOGIN_MODAL_EVENTS"].LOGIN, {
                adapter,
                loginParams: {
                    loginProvider: loginParams.loginProvider,
                    login_hint: loginParams.login_hint,
                    name: loginParams.name
                }
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "setState", (newState)=>{
            this.stateEmitter.emit("STATE_UPDATED", newState);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "updateWalletConnect", (walletConnectUri)=>{
            if (!walletConnectUri) return;
            this.setState({
                walletConnectUri
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "handleAdapterData", (adapterData)=>{
            if (adapterData.adapterName === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2) {
                const walletConnectData = adapterData.data;
                this.updateWalletConnect(walletConnectData.uri);
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$defineProperty$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, "subscribeCoreEvents", (listener)=>{
            listener.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_EVENTS"].CONNECTING, (data)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].info("connecting with adapter", data);
                // don't show loader in case of wallet connect, because currently it listens for incoming for incoming
                // connections without any user interaction.
                if ((data === null || data === void 0 ? void 0 : data.adapter) !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$wallet$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WALLET_ADAPTERS"].WALLET_CONNECT_V2) {
                    // const provider = data?.loginProvider || "";
                    this.setState({
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTING
                    });
                }
            });
            listener.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_EVENTS"].CONNECTED, (data)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].debug("connected with adapter", data);
                // only show success if not being reconnected again.
                if (!data.reconnected) {
                    this.setState({
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTED,
                        modalVisibility: true,
                        postLoadingMessage: "modal.post-loading.connected"
                    });
                } else {
                    this.setState({
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].CONNECTED
                    });
                }
            });
            // TODO: send adapter name in error
            listener.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_EVENTS"].ERRORED, (error)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$loglevel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__log$3e$__["log"].error("error", error, error.message);
                if (error.code === 5000) {
                    if (this.uiConfig.displayErrorsOnModal) this.setState({
                        modalVisibility: true,
                        postLoadingMessage: error.message || "modal.post-loading.something-wrong",
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].ERRORED
                    });
                    else this.setState({
                        modalVisibility: false
                    });
                } else {
                    this.setState({
                        modalVisibility: true,
                        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED
                    });
                }
            });
            listener.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_EVENTS"].DISCONNECTED, ()=>{
                this.setState({
                    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MODAL_STATUS"].INITIALIZED,
                    externalWalletsVisibility: false
                });
            // this.toggleMessage("");
            });
            listener.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$base$2f$dist$2f$lib$2e$esm$2f$adapter$2f$IAdapter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ADAPTER_EVENTS"].ADAPTER_DATA_UPDATED, (adapterData)=>{
                this.handleAdapterData(adapterData);
            });
        });
        this.uiConfig = _uiConfig;
        if (!_uiConfig.logoDark) this.uiConfig.logoDark = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_LOGO_DARK"];
        if (!_uiConfig.logoLight) this.uiConfig.logoLight = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_LOGO_LIGHT"];
        if (!_uiConfig.mode) this.uiConfig.mode = "light";
        if (!_uiConfig.modalZIndex) this.uiConfig.modalZIndex = "99998";
        if (typeof _uiConfig.displayErrorsOnModal === "undefined") this.uiConfig.displayErrorsOnModal = true;
        if (!_uiConfig.appName) this.uiConfig.appName = "Web3Auth";
        if (!_uiConfig.loginGridCol) this.uiConfig.loginGridCol = 3;
        if (!_uiConfig.primaryButton) this.uiConfig.primaryButton = "socialLogin";
        if (!_uiConfig.defaultLanguage) this.uiConfig.defaultLanguage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUserLanguage"])(_uiConfig.defaultLanguage);
        this.stateEmitter = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$auth$2f$dist$2f$lib$2e$esm$2f$jrpc$2f$safeEventEmitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SafeEventEmitter"]();
        this.chainNamespace = _uiConfig.chainNamespace;
        this.walletRegistry = _uiConfig.walletRegistry;
        this.subscribeCoreEvents(this.uiConfig.adapterListener);
    }
    get isDark() {
        return this.uiConfig.mode === "dark" || this.uiConfig.mode === "auto" && window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
}
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/index.js [app-ssr] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
}}),
"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/index.js [app-ssr] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$config$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/config.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$interfaces$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/interfaces.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$loginModal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/loginModal.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$web3auth$2f$modal$2f$node_modules$2f40$web3auth$2f$ui$2f$dist$2f$lib$2e$esm$2f$packages$2f$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/index.js [app-ssr] (ecmascript) <locals>");
}}),

};

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_48be3f._.js.map