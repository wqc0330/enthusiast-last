module.exports = {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/spanish.json.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>spanish),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Verifica tu cuenta {{adapter}} para continuar",
    "adapter-loader.message1": "Verifique su {{adapter}}",
    "adapter-loader.message2": "cuenta para continuar",
    "errors-invalid-email": "Correo electrónico no válido",
    "errors-invalid-number": "Número de teléfono no válido",
    "errors-invalid-number-email": "Correo electrónico o número de teléfono no válido",
    "errors-required": "Campo obligatorio",
    "external.back": "Atrás",
    "external.connect": "Conectar con la billetera",
    "external.search-text": "¿No ves tu billetera?",
    "external.search-subtext": "Intenta buscar en su lugar",
    "external.connect-wallet": "Conectar billetera",
    "external.continue": "Continuar con billetera externa",
    "external.dont-have": "No tiene",
    "external.get": "Obtener",
    "external.get-wallet": "Obtener billetera",
    "external.install-browser-extension": "Instalar extensión {{browser}}",
    "external.install-mobile-app": "Instalar aplicación {{os}}",
    "external.installed": "Instalado",
    "external.no-wallets-found": "No se encontraron billeteras",
    "external.search-wallet": "Buscar a través de {{count}} billeteras...",
    "external.title": "Billetera Externa",
    "external.walletconnect-connect": "Conectar",
    "external.walletconnect-copy": "Escanee con una billetera compatible con WalletConnect o haga clic en el código QR para copiarlo en su portapapeles.",
    "external.walletconnect-subtitle": "Escanear el código QR con una billetera compatible con WalletConnect",
    "footer.message": "Inicio de sesión con autocustodia por",
    "footer.message-new": "Autocustodia a través de",
    "footer.policy": "Política de privacidad",
    "footer.terms": "Términos de Uso",
    "footer.terms-service": "Términos de servicio",
    "footer.version": "Versión",
    "header-subtitle": "Seleccione una de las siguientes opciones para continuar",
    "header-subtitle-name": "Su billetera {{appName}} con un solo clic",
    "header-subtitle-new": "Su billetera blockchain con un solo clic",
    "header-title": "Iniciar sesión",
    "header-tooltip-desc": "La billetera sirve como una cuenta para almacenar y administrar sus activos digitales en la blockchain.",
    "header-tooltip-title": "Billetera",
    "network.add-request": "Este sitio está solicitando agregar una red",
    "network.cancel": "Cancelar",
    "network.from": "De",
    "network.proceed": "Continuar",
    "network.switch-request": "Este sitio está solicitando cambiar de red",
    "network.to": "A",
    "passkey.add": "Añadir Passkey",
    "passkey.haveExisting": "¿Tiene un passkey existente?",
    "passkey.learn-more": "Aprende más",
    "passkey.or": "o",
    "passkey.register-desc": "Con passkeys, puedes verificar tu identidad a través de tu rostro, huella digital o claves de seguridad.",
    "passkey.register-title": "Registrarse Passkey",
    "passkey.use": "Tengo una Passkey",
    "popup.phone-body": "Su código de país se detectará automáticamente, pero si está utilizando un número de teléfono de otro país, deberá ingresar manualmente el código de país correcto.",
    "popup.phone-header": "Número de teléfono y código de país",
    "post-loading.connected": "Estás conectado con tu cuenta",
    "post-loading.something-wrong": "¡Algo salió mal!",
    "social.continue": "Continuar con",
    "social.continueCustom": "Continuar con {{adapter}}",
    "social.email": "Correo electrónico",
    "social.email-continue": "Continuar con correo electrónico",
    "social.email-new": "nombre@ejemplo.com",
    "social.passwordless-cta": "Continuar",
    "social.passwordless-login": "Acceso",
    "social.passwordless-title": "Email o teléfono",
    "social.phone": "Teléfono",
    "social.policy": "No almacenamos ningún dato relacionado con sus inicios de sesión sociales.",
    "social.sms": "Móvil",
    "social.sms-continue": "Continuar con móvil",
    "social.sms-invalid-number": "Número de teléfono inválido",
    "social.sms-placeholder-text": "Por ej.:",
    "social.view-less": "Ver menos",
    "social.view-less-socials": "Ver menos socials",
    "social.view-more": "Ver más",
    "social.view-more-socials": "Ver más socials"
};
var spanish = {
    modal: modal
};
;
}}),

};

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_spanish_json_428af9.js.map