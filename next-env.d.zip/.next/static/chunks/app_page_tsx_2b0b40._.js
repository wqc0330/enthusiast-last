(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_2b0b40._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_2b0b40._.js",
  "chunks": [
    "static/chunks/node_modules_060193._.js",
    "static/chunks/_6d7661._.js"
  ],
  "source": "dynamic"
});
