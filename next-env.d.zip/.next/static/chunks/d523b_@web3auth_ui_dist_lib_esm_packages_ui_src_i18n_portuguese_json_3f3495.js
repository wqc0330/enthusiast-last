(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_portuguese_json_3f3495.js", {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/portuguese.json.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>portuguese),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Verifique a sua conta {{adapter}} para continuar",
    "adapter-loader.message1": "Verifique o(a) seu/sua {{adapter}}",
    "adapter-loader.message2": "conta para continuar",
    "errors-invalid-email": "E-mail inválido",
    "errors-invalid-number": "Número de telefone inválido",
    "errors-invalid-number-email": "Email ou número de telefone inválido",
    "errors-required": "Obrigatório",
    "external.back": "Voltar",
    "external.connect": "Continuar com uma carteira",
    "external.search-text": "Não vê sua carteira?",
    "external.search-subtext": "Tente pesquisar",
    "external.connect-wallet": "Conectar carteira",
    "external.continue": "Continuar com carteira externa",
    "external.dont-have": "Não tem",
    "external.get": "Obter",
    "external.get-wallet": "Obter carteira",
    "external.install-browser-extension": "Instalar extensão {{browser}}",
    "external.install-mobile-app": "Instalar aplicativo {{os}}",
    "external.installed": "Instalado",
    "external.no-wallets-found": "Nenhuma carteira encontrada",
    "external.search-wallet": "Pesquisar através de {{count}} carteiras...",
    "external.title": "Carteira Externa",
    "external.walletconnect-connect": "Conectar",
    "external.walletconnect-copy": "Digitalize com uma carteira compatível com WalletConnect ou clique no código QR para copiar para sua área de transferência.",
    "external.walletconnect-subtitle": "Digitalize o código QR com uma carteira compatível com WalletConnect",
    "footer.message": "Login de autocustódia por",
    "footer.message-new": "Autoconfiança via",
    "footer.policy": "Política de Privacidade",
    "footer.terms": "Termos de Uso",
    "footer.terms-service": "Termos de Serviço",
    "footer.version": "Versão",
    "header-subtitle": "Selecione uma das seguintes opções para continuar",
    "header-subtitle-name": "Sua carteira {{appName}} com um clique",
    "header-subtitle-new": "Sua carteira de blockchain com um clique",
    "header-title": "Entrar",
    "header-tooltip-desc": "A carteira serve como uma conta para armazenar e gerenciar seus ativos digitais na blockchain.",
    "header-tooltip-title": "Carteira",
    "network.add-request": "Este site está solicitando adicionar uma rede",
    "network.cancel": "Cancelar",
    "network.from": "De",
    "network.proceed": "Prosseguir",
    "network.switch-request": "Este site está solicitando trocar de rede",
    "network.to": "Para",
    "passkey.add": "Adicionar Passkey",
    "passkey.haveExisting": "Você já possui um passkey?",
    "passkey.learn-more": "Saber mais",
    "passkey.or": "ou",
    "passkey.register-desc": "Com passkeys, você pode verificar sua identidade por meio de seu rosto, impressão digital ou chaves de segurança.",
    "passkey.register-title": "Registre-se Passkey",
    "passkey.use": "Eu tenho uma passkey",
    "popup.phone-body": "O código do seu país será detectado automaticamente, mas se estiver usando um número de telefone de um país diferente, você precisará inserir manualmente o código correto do país.",
    "popup.phone-header": "Número de telefone e código do país",
    "post-loading.connected": "Você está conectado com sua conta",
    "post-loading.something-wrong": "Algo deu errado!",
    "social.continue": "Continuar com",
    "social.continueCustom": "Continue com o {{adapter}}",
    "social.email": "Email",
    "social.email-continue": "Continuar com email",
    "social.email-new": "nome@exemplo.com",
    "social.passwordless-cta": "Continuar",
    "social.passwordless-login": "Conecte-se",
    "social.passwordless-title": "Email ou telefone",
    "social.phone": "Telefone",
    "social.policy": "Não armazenamos nenhum dado relacionado ao seu login por rede social.",
    "social.sms": "Móvel",
    "social.sms-continue": "Continuar com o celular",
    "social.sms-invalid-number": "Número de telefone inválido",
    "social.sms-placeholder-text": "Por exemplo:",
    "social.view-less": "Ver menos",
    "social.view-less-socials": "Ver menos socials",
    "social.view-more": "Ver mais",
    "social.view-more-socials": "Ver mais socials"
};
var portuguese = {
    modal: modal
};
;
}}),
}]);

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_portuguese_json_3f3495.js.map