(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_mandarin_json_752830.js", {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/mandarin.json.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>mandarin),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "验证您的{{adapter}}帐户以继续",
    "adapter-loader.message1": "在您的{{adapter}}上验证",
    "adapter-loader.message2": "帐号继续",
    "errors-invalid-email": "无效的电子邮件",
    "errors-invalid-number": "电话号码无效",
    "errors-invalid-number-email": "无效的电子邮件或电话号码",
    "errors-required": "必填",
    "external.back": "返回",
    "external.connect": "继续使用钱包",
    "external.search-text": "没看到你的钱包吗？",
    "external.search-subtext": "尝试改为搜索",
    "external.connect-wallet": "连接钱包",
    "external.continue": "继续使用外部钱包",
    "external.dont-have": "没有",
    "external.get": "获取",
    "external.get-wallet": "获取钱包",
    "external.install-browser-extension": "安装{{browser}}扩展",
    "external.install-mobile-app": "安装{{os}}应用",
    "external.installed": "已安装",
    "external.no-wallets-found": "没有找到钱包",
    "external.search-wallet": "搜索{{count}}个钱包...",
    "external.title": "外部钱包",
    "external.walletconnect-connect": "连接",
    "external.walletconnect-copy": "使用支持 WalletConnect 的钱包进行扫描或单击二维码以复制到剪贴板。",
    "external.walletconnect-subtitle": "使用兼容 WalletConnect 的钱包扫描 QR 码",
    "footer.message": "自托管登录由",
    "footer.message-new": "自我castody通过",
    "footer.policy": "隐私政策",
    "footer.terms": "使用条款",
    "footer.terms-service": "服务条款",
    "footer.version": "版本",
    "header-subtitle": "选择以下选项以继续",
    "header-subtitle-name": "一键点击您的 {{appName}} 钱包",
    "header-subtitle-new": "一键点击您的区块链钱包",
    "header-title": "登录",
    "header-tooltip-desc": "钱包作为一个账户用于在区块链上存储和管理您的数字资产。",
    "header-tooltip-title": "钱包",
    "network.add-request": "此站点正在请求添加网络",
    "network.cancel": "取消",
    "network.from": "从",
    "network.proceed": "继续",
    "network.switch-request": "此站点正在请求切换网络",
    "network.to": "至",
    "passkey.add": "添加Passkey",
    "passkey.haveExisting": "已有 passkey 吗？",
    "passkey.learn-more": "了解更多",
    "passkey.or": "或者",
    "passkey.register-desc": "使用passkeys，您可以通过面部、指纹或安全密钥验证您的身份。",
    "passkey.register-title": "注册Passkey",
    "passkey.use": "我有一个Passkey",
    "popup.phone-body": "您的国家代码将自动检测到，但如果您使用其他国家/地区的电话号码，您需要手动输入正确的国家代码。",
    "popup.phone-header": "电话号码和国家代码",
    "post-loading.connected": "您与您的帐户有联系",
    "post-loading.something-wrong": "出了些问题！",
    "social.continue": "继续",
    "social.continueCustom": "继续使用{{adapter}}",
    "social.email": "电子邮件",
    "social.email-continue": "继续使用电子邮件",
    "social.email-new": "name@example.com",
    "social.passwordless-cta": "继续",
    "social.passwordless-login": "登录",
    "social.passwordless-title": "邮件或电话",
    "social.phone": "电话",
    "social.policy": "我们不存储与您的社交登录相关的任何数据。",
    "social.sms": "移动",
    "social.sms-continue": "继续使用移动设备",
    "social.sms-invalid-number": "无效的电话号码",
    "social.sms-placeholder-text": "例如：",
    "social.view-less": "少查看",
    "social.view-less-socials": "查看更少socials",
    "social.view-more": "查看更多",
    "social.view-more-socials": "查看更多socials"
};
var mandarin = {
    modal: modal
};
;
}}),
}]);

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_mandarin_json_752830.js.map