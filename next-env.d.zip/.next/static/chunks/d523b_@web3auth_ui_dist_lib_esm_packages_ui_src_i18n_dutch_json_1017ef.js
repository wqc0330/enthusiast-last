(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_dutch_json_1017ef.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_dutch_json_1017ef.js",
  "chunks": [
    "static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_dutch_json_66f341.js"
  ],
  "source": "dynamic"
});
