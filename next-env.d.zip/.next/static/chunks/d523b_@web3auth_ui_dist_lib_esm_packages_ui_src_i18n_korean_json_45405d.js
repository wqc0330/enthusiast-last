(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_korean_json_45405d.js", {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/korean.json.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>korean),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "계속하려면 {{adapter}} 계정을 인증하세요",
    "adapter-loader.message1": "{{adapter}}를 인증하세요",
    "adapter-loader.message2": "계속할 계정",
    "errors-invalid-email": "유효하지 않은 이메일",
    "errors-invalid-number": "유효하지 않은 전화번호",
    "errors-invalid-number-email": "유효하지 않은 이메일 또는 전화번호",
    "errors-required": "필수",
    "external.back": "뒤로",
    "external.connect": "지갑으로 계속하기",
    "external.search-text": "지갑이 보이지 않나요?",
    "external.search-subtext": "검색해보세요",
    "external.connect-wallet": "지갑 연결",
    "external.continue": "외부 지갑으로 계속하기",
    "external.dont-have": "없음",
    "external.get": "받기",
    "external.get-wallet": "지갑 받기",
    "external.install-browser-extension": "{{browser}} 확장 프로그램 설치",
    "external.install-mobile-app": "{{os}} 앱 설치",
    "external.installed": "설치 완료",
    "external.no-wallets-found": "지갑을 찾을 수 없습니다.",
    "external.search-wallet": "{{count}}개의 지갑을 검색 중입니다...",
    "external.title": "외부 지갑",
    "external.walletconnect-connect": "연결",
    "external.walletconnect-copy": "WalletConnect 호환 지갑으로 스캔하거나, QR 코드를 클릭하여 클립보드에 복사하세요.",
    "external.walletconnect-subtitle": "WalletConnect 호환 지갑으로 QR 코드를 스캔하세요",
    "footer.message": "자가 관리형 로그인",
    "footer.message-new": "셀프 커스터디",
    "footer.policy": "개인정보 처리방침",
    "footer.terms": "이용 약관",
    "footer.terms-service": "서비스 약관",
    "footer.version": "버전",
    "header-subtitle": "계속하려면 다음 중 하나를 선택하세요",
    "header-subtitle-name": "한 번의 클릭으로 {{appName}} 지갑 이용하기",
    "header-subtitle-new": "한 번의 클릭으로 블록체인 지갑 이용하기",
    "header-title": "로그인",
    "header-tooltip-desc": "이 지갑은 블록체인 상에서 디지털 자산을 보관하고 관리하는 데 사용되는 계정입니다.",
    "header-tooltip-title": "지갑",
    "network.add-request": "이 사이트에서 네트워크 추가를 요청하고 있습니다",
    "network.cancel": "취소",
    "network.from": "보낸 사람",
    "network.proceed": "계속",
    "network.switch-request": "이 사이트에서 네트워크 전환을 요청하고 있습니다",
    "network.to": "받는 사람",
    "passkey.add": "Passkey 추가",
    "passkey.haveExisting": "기존 passkey가 있나요?",
    "passkey.learn-more": "더 알아보기",
    "passkey.or": "또는",
    "passkey.register-desc": "passkeys 사용 시 얼굴, 지문 또는 보안 키를 통해 본인임을 인증할 수 있습니다.",
    "passkey.register-title": "Passkey 등록",
    "passkey.use": "기존 Passkey 사용하기",
    "popup.phone-body": "국가 코드는 자동으로 감지됩니다. 그러나 다른 국가의 전화번호를 사용하는 경우, 올바른 국가 코드를 수동으로 입력해야 합니다.",
    "popup.phone-header": "전화번호 및 국가 코드",
    "post-loading.connected": "계정에 연결되었습니다",
    "post-loading.something-wrong": "오류가 발생했습니다!",
    "social.continue": "계속하기",
    "social.continueCustom": "{{adapter}}로 계속하기",
    "social.email": "이메일",
    "social.email-continue": "이메일로 계속하기",
    "social.email-new": "name@example.com",
    "social.passwordless-cta": "계속",
    "social.passwordless-login": "로그인",
    "social.passwordless-title": "이메일 또는 전화번호",
    "social.phone": "전화번호",
    "social.policy": "저희는 소셜 로그인과 관련된 어떠한 데이터도 저장하지 않습니다.",
    "social.sms": "모바일",
    "social.sms-continue": "모바일로 계속하기",
    "social.sms-invalid-number": "유효하지 않은 전화번호",
    "social.sms-placeholder-text": "예시:",
    "social.view-less": "간략히 보기",
    "social.view-less-socials": "Socials 간략히 보기",
    "social.view-more": "더보기",
    "social.view-more-socials": "Socials 더보기"
};
var korean = {
    modal: modal
};
;
}}),
}]);

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_korean_json_45405d.js.map