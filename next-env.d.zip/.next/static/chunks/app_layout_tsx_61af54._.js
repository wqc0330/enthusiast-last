(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__9d1267._.css",
    "static/chunks/node_modules_next_dist_4fd918._.js",
    "static/chunks/node_modules_@web3auth_auth_dist_lib_esm_aaa873._.js",
    "static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_323cfd._.js",
    "static/chunks/node_modules_elliptic_9795d5._.js",
    "static/chunks/node_modules_f4481a._.js",
    "static/chunks/node_modules_readable-stream_lib_f3f7fe._.js",
    "static/chunks/node_modules_@ethereumjs_util_dist_esm_6fd64a._.js",
    "static/chunks/node_modules_645925._.js",
    "static/chunks/node_modules_@walletconnect_core_dist_index_es_d6db9b.js",
    "static/chunks/node_modules_@walletconnect_sign-client_dist_index_es_443966.js",
    "static/chunks/node_modules_@web3auth_b11b73._.js",
    "static/chunks/node_modules_ethers_d74e2f._.js",
    "static/chunks/node_modules_@walletconnect_c727e0._.js",
    "static/chunks/node_modules_@stablelib_e81ff8._.js",
    "static/chunks/node_modules_@ethersproject_294fd3._.js",
    "static/chunks/node_modules_e172ef._.js",
    "static/chunks/_c7737b._.js",
    "static/chunks/node_modules_599652._.js"
  ],
  "source": "dynamic"
});
