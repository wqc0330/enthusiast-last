(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_dutch_json_66f341.js", {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/dutch.json.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>dutch),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Verifieer uw {{adapter}}-account om door te gaan",
    "adapter-loader.message1": "Verifieer uw {{adapter}}",
    "adapter-loader.message2": "account om door te gaan",
    "errors-invalid-email": "Ongeldig e-mailadres",
    "errors-invalid-number": "Ongeldig telefoonnummer",
    "errors-invalid-number-email": "Ongeldig e-mailadres of telefoonnummer",
    "errors-required": "Vereist",
    "external.back": "Terug",
    "external.connect": "Ga verder met een portemonnee",
    "external.search-text": "Ziet u uw portemonnee niet?",
    "external.search-subtext": "Probeer in plaats daarvan te zoeken",
    "external.connect-wallet": "Verbinden met portemonnee",
    "external.continue": "Ga verder met externe portemonnee",
    "external.dont-have": "Heb niet",
    "external.get": "Krijgen",
    "external.get-wallet": "Portemonnee krijgen",
    "external.install-browser-extension": "{{browser}}-extensie installeren",
    "external.install-mobile-app": "Installeer {{os}}-app",
    "external.installed": "Geïnstalleerd",
    "external.no-wallets-found": "Geen portefeuilles gevonden",
    "external.search-wallet": "Zoeken door {{count}} portemonnees...",
    "external.title": "Externe portemonnee",
    "external.walletconnect-connect": "Verbinden",
    "external.walletconnect-copy": "Scan met een WalletConnect-ondersteunde portemonnee of klik op de QR-code om naar uw klembord te kopiëren.",
    "external.walletconnect-subtitle": "Scan de QR-code met een WalletConnect-compatibele portemonnee",
    "footer.message": "Zelfbeheerde login door",
    "footer.message-new": "Zelfkusten via",
    "footer.policy": "Privacybeleid",
    "footer.terms": "Gebruiksvoorwaarden",
    "footer.terms-service": "Gebruiksvoorwaarden",
    "footer.version": "Versie",
    "header-subtitle": "Selecteer een van de volgende opties om door te gaan",
    "header-subtitle-name": "Uw {{appName}}-portemonnee met één klik",
    "header-subtitle-new": "Uw blockchain-portemonnee met één klik",
    "header-title": "Aanmelden",
    "header-tooltip-desc": "De portemonnee dient als een account om uw digitale activa op de blockchain op te slaan en te beheren.",
    "header-tooltip-title": "Portemonnee",
    "network.add-request": "Deze site vraagt om een netwerk toe te voegen",
    "network.cancel": "Annuleren",
    "network.from": "Van",
    "network.proceed": "Doorgaan",
    "network.switch-request": "Deze site vraagt om over te schakelen naar een ander netwerk",
    "network.to": "Naar",
    "passkey.add": "Passkey toevoegen",
    "passkey.haveExisting": "Heeft u een bestaande passkey?",
    "passkey.learn-more": "Kom meer te weten",
    "passkey.or": "of",
    "passkey.register-desc": "Met passkeys kunt u uw identiteit verifiëren via uw gezicht, vingerafdruk of beveiligingssleutels.",
    "passkey.register-title": "Registreer Passkey",
    "passkey.use": "Ik heb een passkey",
    "popup.phone-body": "Uw landcode wordt automatisch gedetecteerd, maar als u een telefoonnummer uit een ander land gebruikt, moet u handmatig de juiste landcode invoeren.",
    "popup.phone-header": "Telefoonnummer en landcode",
    "post-loading.connected": "U bent verbonden met uw account",
    "post-loading.something-wrong": "Er is iets fout gegaan!",
    "social.continue": "Doorgaan met",
    "social.continueCustom": "Doorgaan met {{adapter}}",
    "social.email": "E-mail",
    "social.email-continue": "Doorgaan met e-mail",
    "social.email-new": "naam@voorbeeld.com",
    "social.passwordless-cta": "Doorgaan",
    "social.passwordless-login": "Log in",
    "social.passwordless-title": "E-mail of telefoon",
    "social.phone": "Telefoon",
    "social.policy": "We slaan geen gegevens op die verband houden met uw sociale logins.",
    "social.sms": "Mobiel",
    "social.sms-continue": "Doorgaan met mobiel",
    "social.sms-invalid-number": "Ongeldig telefoonnummer",
    "social.sms-placeholder-text": "Bijv.:",
    "social.view-less": "Minder bekijken",
    "social.view-less-socials": "Bekijk minder socials",
    "social.view-more": "Meer bekijken",
    "social.view-more-socials": "Bekijk meer socials"
};
var dutch = {
    modal: modal
};
;
}}),
}]);

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_dutch_json_66f341.js.map