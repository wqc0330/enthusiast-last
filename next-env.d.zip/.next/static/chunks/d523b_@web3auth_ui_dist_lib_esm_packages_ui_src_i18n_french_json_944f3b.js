(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_i18n_french_json_944f3b.js", {

"[project]/node_modules/@web3auth/modal/node_modules/@web3auth/ui/dist/lib.esm/packages/ui/src/i18n/french.json.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>french),
    "modal": (()=>modal)
});
var modal = {
    "adapter-loader.message": "Vérifiez votre compte {{adapter}} pour continuer",
    "adapter-loader.message1": "Vérifiez votre {{adapter}}",
    "adapter-loader.message2": "compte pour continuer",
    "errors-invalid-email": "E-mail invalide",
    "errors-invalid-number": "Numéro de téléphone invalide",
    "errors-invalid-number-email": "Adresse e-mail ou numéro de téléphone invalide",
    "errors-required": "Champ obligatoire",
    "external.back": "Retour",
    "external.connect": "Continuer avec un portefeuille",
    "external.search-text": "Vous ne voyez pas votre portefeuille ?",
    "external.search-subtext": "Essayez plutôt de rechercher",
    "external.connect-wallet": "Connecter le portefeuille",
    "external.continue": "Continuer avec le portefeuille externe",
    "external.dont-have": "N'avez pas",
    "external.get": "Obtenir",
    "external.get-wallet": "Obtenir un portefeuille",
    "external.installed": "Installé",
    "external.no-wallets-found": "Aucun portefeuille trouvé",
    "external.search-wallet": "Rechercher parmi {{count}} portefeuilles...",
    "external.title": "Portefeuille externe",
    "external.walletconnect-connect": "Se connecter",
    "external.walletconnect-copy": "Scannez avec un portefeuille pris en charge par WalletConnect ou cliquez sur le code QR pour le copier dans votre presse-papiers.",
    "external.walletconnect-subtitle": "Scannez le code QR avec un portefeuille compatible WalletConnect",
    "footer.message": "Connexion en autonomie par",
    "footer.message-new": "Auto-cuir via",
    "footer.policy": "Politique de confidentialité",
    "footer.terms": "Conditions d'utilisation",
    "footer.terms-service": "Conditions d'utilisation",
    "footer.version": "Version",
    "header-subtitle": "Sélectionnez l'une des options suivantes pour continuer",
    "header-subtitle-name": "Votre portefeuille {{appName}} en un clic",
    "header-subtitle-new": "Votre portefeuille blockchain en un clic",
    "header-title": "Se connecter",
    "header-tooltip-desc": "Le portefeuille sert de compte pour stocker et gérer vos actifs numériques sur la blockchain.",
    "header-tooltip-title": "Portefeuille",
    "network.add-request": "Ce site demande d'ajouter un réseau",
    "network.cancel": "Annuler",
    "network.from": "De",
    "network.proceed": "Continuer",
    "network.switch-request": "Ce site demande de changer de réseau",
    "network.to": "À",
    "passkey.add": "Ajouter Passkey",
    "passkey.haveExisting": "Vous disposez déjà d'un passkey ?",
    "passkey.learn-more": "Apprendre encore plus",
    "passkey.or": "ou",
    "passkey.register-desc": "Avec passkeys, vous pouvez vérifier votre identité grâce à votre visage, vos empreintes digitales ou vos clés de sécurité.",
    "passkey.register-title": "Inscrivez-vous Passkey",
    "passkey.use": "J'ai un passkey",
    "popup.phone-body": "Votre code pays sera détecté automatiquement, mais si vous utilisez un numéro de téléphone d'un autre pays, vous devrez saisir manuellement le bon code pays.",
    "popup.phone-header": "Numéro de téléphone et code pays",
    "post-loading.connected": "Vous êtes connecté avec votre compte",
    "post-loading.something-wrong": "Quelque chose s'est mal passé!",
    "social.continue": "Continuer avec",
    "social.continueCustom": "Continuer avec {{adapter}}",
    "social.email": "Email",
    "social.email-continue": "Continuer avec l'email",
    "social.email-new": "nom@exemple.com",
    "social.passwordless-cta": "Continuer",
    "social.passwordless-login": "Se connecter",
    "social.passwordless-title": "Email ou téléphone",
    "social.phone": "Téléphone",
    "social.policy": "Nous ne stockons aucune donnée liée à vos connexions sociales.",
    "social.sms": "Mobile",
    "social.sms-continue": "Continuer avec le mobile",
    "social.sms-invalid-number": "Numéro de téléphone invalide",
    "social.sms-placeholder-text": "Par exemple :",
    "social.view-less": "Voir moins",
    "social.view-less-socials": "Voir moins socials",
    "social.view-more": "Voir plus",
    "social.view-more-socials": "Voir plus socials"
};
var french = {
    modal: modal
};
;
}}),
}]);

//# sourceMappingURL=d523b_%40web3auth_ui_dist_lib_esm_packages_ui_src_i18n_french_json_944f3b.js.map