(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_demo_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_demo_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_@web3auth_auth_dist_lib_esm_aaa873._.js",
    "static/chunks/d523b_@web3auth_ui_dist_lib_esm_packages_ui_src_323cfd._.js",
    "static/chunks/node_modules_elliptic_9795d5._.js",
    "static/chunks/node_modules_f4481a._.js",
    "static/chunks/node_modules_6f7b52._.js",
    "static/chunks/node_modules_readable-stream_lib_f3f7fe._.js",
    "static/chunks/node_modules_ethers_lib_esm_abi_0c3eee._.js",
    "static/chunks/node_modules_ethers_lib_esm_providers_f5fd2e._.js",
    "static/chunks/node_modules_ethers_lib_esm_41f863._.js",
    "static/chunks/node_modules_2a8b81._.js",
    "static/chunks/node_modules_@ethereumjs_util_dist_esm_6fd64a._.js",
    "static/chunks/node_modules_@walletconnect_core_dist_index_es_d6db9b.js",
    "static/chunks/node_modules_@walletconnect_sign-client_dist_index_es_443966.js",
    "static/chunks/node_modules_@web3auth_b11b73._.js",
    "static/chunks/node_modules_@walletconnect_c727e0._.js",
    "static/chunks/node_modules_@stablelib_e81ff8._.js",
    "static/chunks/node_modules_@ethersproject_294fd3._.js",
    "static/chunks/node_modules_465b8c._.js",
    "static/chunks/_472fb5._.js",
    "static/chunks/node_modules_cc33dd._.js"
  ],
  "source": "dynamic"
});
